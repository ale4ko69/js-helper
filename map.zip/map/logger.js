export function log(str){
    console.log(str)
}
