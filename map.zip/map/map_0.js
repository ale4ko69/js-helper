export function Map(oHighcharts, oRootDom, oRootFooter) {
    let isDebug = true
    const urlEpMap = "https://code.highcharts.com/mapdata"
    const urlDefaultMap = "/custom/world-highres2.topo.json" //world-continents.topo.json; world.topo.json; world-highres2.topo.json
    const Highcharts = oHighcharts;
    const root = document.querySelector(oRootDom);
    let mapContainer
    let mapFooter
    let topology;
    let dataPointers;
    let dataCountries;
    let chart;
    let geojson;
    let _btnZoomReset
    let _btnZoomIn
    let _btnZoomOut
    let _btnZoomBelgium
    let currentMap = ''
    let mapId
    let footerId
    let hRisk = 0
    let mRisk = 0
    let lRisk = 0
    let noRisk = 0

    const getRootHTML = () => `
        <div class="map-container" id=${mapId}></div>
        <div class="map-footer"  id=${footerId}>
            <button id="zoomIn"> + </button>
            <button id="zoomOut"> - </button>
            <button id="zoomReset">Reset</button>
            Risk Score: <a href="#" onclick="map.renderMap('h')">High <span id="${mapId}-risk-h"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="#" onclick="map.renderMap('m')">Medium <span id="${mapId}-risk-m"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="#" onclick="map.renderMap('l')">Low <span id="${mapId}-risk-l"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="#" onclick="map.renderMap('n')">No Score <span id="${mapId}-risk-n"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
    `

    Highcharts.wrap(Highcharts.Chart.prototype, 'showResetZoom', (proceed) => {
    });

    async function Init(){
        try {

            const rndID = generateRiskRandom(1000)
            mapId = `map-${rndID}`
            footerId = `footer-${rndID}`

            root.innerHTML = getRootHTML()

            mapContainer    = root.querySelector(`#${mapId}`)
            mapFooter       = root.querySelector('.map-footer')
            _btnZoomReset   = document.querySelector('#zoomReset')
            _btnZoomIn      = document.querySelector('#zoomIn')
            _btnZoomOut     = document.querySelector('#zoomOut')

            // Get World Map
            await getTopology();

            // Get Countries
            const data = await getData()

            data.forEach((p) => {
                p.push(p[0]);
            });

            dataCountries = data

            // Select data (TODO from server)
            dataPointers = prepareData(getFullSites());

            await renderByRiskSites();

            //---- Bind Buttons Events
            bindFooterEvents()

            //---- Create Risk Score Legends
            animateRiskScore()

        } catch (err) {
            console.log(err);
        }
    }

    async function getTopology(epMap){
        const url = epMap ?? urlDefaultMap
        const _topology = await fetch(`${urlEpMap}${url}`).then(response => response.json());

        topology = _topology;
        geojson = Highcharts.topo2geo(topology);

        // const _eu = await fetch(`https://code.highcharts.com/mapdata/custom/european-union.topo.json`).then(response => response.json());
        // eu = _eu;
        // const _data = new Array(_eu.objects.default.geometries.length)
        // .fill(1)
        // .map((val, i) => i);

        if(isDebug) {
            console.log('map.js - getTopology -> topology', topology)
            // console.log('map.js - getTopology -> eu', eu)
            // console.log('map.js - getTopology -> eu _data', _data)
            console.log('map.js - getTopology -> geojson', geojson)
        }

        return topology;
    }

    async function getData(url){
        //TODO GET FROM SERVER
        // Prepare demo data. The data is joined to map using value of 'hc-key'
        // property by default. See API docs for 'joinBy' for more info on linking
        // data and map.
        const _data = [
            ["fo", 0],
            // ["um", 1],
            ["us", 2],
            ["jp", 3],
            ["sc", 4],
            ["in", 5],
            ["fr", 6],
            // ["fm", 7],
            ["cn", 8],
            ["pt", 9],
            ["sw", 10],
            ["sh", 11],
            ["br", 12],
            // ["ki", 13],
            ["ph", 14],
            ["mx", 15],
            ["es", 16],
            ["bu", 17],
            ["mv", 18],
            ["sp", 19],
            ["gb", 20],
            ["gr", 21],
            // ["as", 22],
            ["dk", 23],
            ["gl", 24],
            // ["gu", 25],
            ["mp", 26],
            ["pr", 27],
            ["vi", 28],
            ["ca", 29],
            ["st", 30],
            ["cv", 31],
            ["dm", 32],
            ["nl", 33],
            ["jm", 34],
            // ["ws", 35],
            ["om", 36],
            ["vc", 37],
            ["tr", 38],
            ["bd", 39],
            ["lc", 40],
            // ["nr", 41],
            ["no", 42],
            ["kn", 43],
            ["bh", 44],
            // ["to", 45],
            ["fi", 46],
            ["id", 47],
            ["mu", 48],
            ["se", 49],
            ["tt", 50],
            ["my", 51],
            ["pa", 52],
            // ["pw", 53],
            // ["tv", 54],
            // ["mh", 55],
            ["cl", 56],
            ["th", 57],
            ["gd", 58],
            ["ee", 59],
            ["ag", 60],
            ["tw", 61],
            ["bb", 62],
            ["it", 63],
            ["mt", 64],
            // ["vu", 65],
            ["sg", 66],
            ["cy", 67],
            ["lk", 68],
            ["km", 69],
            // ["fj", 70],
            ["ru", 71],
            ["va", 72],
            ["sm", 73],
            ["kz", 74],
            ["az", 75],
            ["tj", 76],
            ["ls", 77],
            ["uz", 78],
            ["ma", 79],
            ["co", 80],
            ["tl", 81],
            ["tz", 82],
            ["ar", 83],
            ["sa", 84],
            ["pk", 85],
            ["ye", 86],
            ["ae", 87],
            ["ke", 88],
            ["pe", 89],
            ["do", 90],
            ["ht", 91],
            ["pg", 92],
            ["ao", 93],
            ["kh", 94],
            ["vn", 95],
            ["mz", 96],
            ["cr", 97],
            ["bj", 98],
            ["ng", 99],
            ["ir", 100],
            ["sv", 101],
            ["sl", 102],
            ["gw", 103],
            ["hr", 104],
            ["bz", 105],
            ["za", 106],
            ["cf", 107],
            ["sd", 108],
            ["cd", 109],
            ["kw", 110],
            ["de", 111],
            ["be", 112],
            ["ie", 113],
            ["kp", 114],
            ["kr", 115],
            ["gy", 116],
            ["hn", 117],
            ["mm", 118],
            ["ga", 119],
            ["gq", 120],
            ["ni", 121],
            ["lv", 122],
            ["ug", 123],
            ["mw", 124],
            ["am", 125],
            ["sx", 126],
            ["tm", 127],
            ["zm", 128],
            ["nc", 129],
            ["mr", 130],
            ["dz", 131],
            ["lt", 132],
            ["et", 133],
            ["er", 134],
            ["gh", 135],
            ["si", 136],
            ["gt", 137],
            ["ba", 138],
            ["jo", 139],
            ["sy", 140],
            ["mc", 141],
            ["al", 142],
            ["uy", 143],
            ["cnm", 144],
            ["mn", 145],
            ["rw", 146],
            ["so", 147],
            ["bo", 148],
            ["cm", 149],
            ["cg", 150],
            ["eh", 151],
            ["rs", 152],
            ["me", 153],
            ["tg", 154],
            ["la", 155],
            ["af", 156],
            ["ua", 157],
            ["sk", 158],
            ["jk", 159],
            ["bg", 160],
            ["qa", 161],
            ["li", 162],
            ["at", 163],
            ["sz", 164],
            ["hu", 165],
            ["ro", 166],
            ["ne", 167],
            ["lu", 168],
            ["ad", 169],
            ["ci", 170],
            ["lr", 171],
            ["bn", 172],
            ["iq", 173],
            ["ge", 174],
            ["gm", 175],
            ["ch", 176],
            ["td", 177],
            ["kv", 178],
            ["lb", 179],
            ["dj", 180],
            ["bi", 181],
            ["sr", 182],
            ["il", 183],
            ["ml", 184],
            ["sn", 185],
            ["gn", 186],
            ["zw", 187],
            ["pl", 188],
            ["mk", 189],
            ["py", 190],
            ["by", 191],
            ["cz", 192],
            ["bf", 193],
            ["na", 194],
            ["ly", 195],
            ["tn", 196],
            ["bt", 197],
            ["md", 198],
            ["ss", 199],
            ["bw", 200],
            ["bs", 201],
            ["nz", 202],
            ["cu", 203],
            ["ec", 204],
            ["au", 205],
            ["ve", 206],
            ["sb", 207],
            ["mg", 208],
            ["is", 209],
            ["eg", 210],
            ["kg", 211],
            ["np", 212]
        ];
        return _data
    }

    function getFullSites() {
        return [
            {
                "srv_id": 63426,
                "srv_name": "Borouge 3 - Relay Server",
                "srv_location": "Al Ruways, UAE",
                "srv_country": "AE",
                "srv_latitude": "24.0858473",
                "srv_longitude": "52.720803",
                "srv_contact_first_name": "Girish",
                "srv_contact_last_name": "Wa******",
                "srv_contact_company": "Borouge3",
                "srv_contact_email": "palznjvbs@tstehxuvi.com",
                "srv_contact_phone": "3886400072"
            },
            {
                "srv_id": 60639,
                "srv_name": "Northern Endeavour - Offshore",
                "srv_location": "Sydney, Australia",
                "srv_country": "AU",
                "srv_latitude": "-33.85359188528898",
                "srv_longitude": "151.23195360575718",
                "srv_contact_first_name": "Shaliesh",
                "srv_contact_last_name": "Sa******",
                "srv_contact_company": "Northern Endeavour",
                "srv_contact_email": "gavypwtgc@ihdtnrzjw.com",
                "srv_contact_phone": "6672364647"
            },
            {
                "srv_id": 63695,
                "srv_name": "TAQA Bratani LTD",
                "srv_location": "Aberdeen, Scotland",
                "srv_country": "GB",
                "srv_latitude": "57.1482429",
                "srv_longitude": "-2.0928095",
                "srv_contact_first_name": "Dave",
                "srv_contact_last_name": "Br******",
                "srv_contact_company": "TAQA Britani Ltd.",
                "srv_contact_email": "wsvexlhsv@rgxzpyyqi.com",
                "srv_contact_phone": "7944055642"
            },
            {
                "srv_id": 60108,
                "srv_name": "SERVE245",
                "srv_location": "Aberdeen, Scotland",
                "srv_country": "GB",
                "srv_latitude": "57.1482429",
                "srv_longitude": "-2.0928095",
                "srv_contact_first_name": "Peter",
                "srv_contact_last_name": "Ho******",
                "srv_contact_company": "BASF",
                "srv_contact_email": "kxompbgwm@bkcgyncjl.com",
                "srv_contact_phone": "2755266324"
            },
            {
                "srv_id": 63422,
                "srv_name": "ADNOC Fertilizer Ruwais",
                "srv_location": "Abu Dhabi, UAE",
                "srv_country": "AE",
                "srv_latitude": "24.4538352",
                "srv_longitude": "54.3774014",
                "srv_contact_first_name": "R",
                "srv_contact_last_name": "Mu******",
                "srv_contact_company": "ADNOC",
                "srv_contact_email": "jdsubniiq@lsseewuus.com",
                "srv_contact_phone": "8110841664"
            },
            {
                "srv_id": 64113,
                "srv_name": "Gasco Bu Hasa",
                "srv_location": "Abu Dhabi, UAE",
                "srv_country": "AE",
                "srv_latitude": "24.4538352",
                "srv_longitude": "54.3774014",
                "srv_contact_first_name": "Raghavan",
                "srv_contact_last_name": "Ma******",
                "srv_contact_company": "Gasco Buhasa",
                "srv_contact_email": "rlnbfxwlj@sefienjdw.com",
                "srv_contact_phone": "621131763"
            },
            {
                "srv_id": 62299,
                "srv_name": "SABIC - Petrokemia Al Jubail",
                "srv_location": "Al Jubail, UAE",
                "srv_country": "AE",
                "srv_latitude": "25.3523528",
                "srv_longitude": "55.3811488",
                "srv_contact_first_name": "Ayman",
                "srv_contact_last_name": "Ku******",
                "srv_contact_company": "Petrokemya",
                "srv_contact_email": "lsizzcufn@anptrhljo.com",
                "srv_contact_phone": "829618900"
            },
            {
                "srv_id": 62302,
                "srv_name": "Sonneborn",
                "srv_location": "Amsterdam, Netherlands",
                "srv_country": "NL",
                "srv_latitude": "52.3730796",
                "srv_longitude": "4.8924534",
                "srv_contact_first_name": "Martien",
                "srv_contact_last_name": "va******",
                "srv_contact_company": "Sonneborn",
                "srv_contact_email": "yvaqgundw@gxgkmgmim.com",
                "srv_contact_phone": "6824615663"
            },
            {
                "srv_id": 61073,
                "srv_name": "Amsterdam Intergration Center",
                "srv_location": "Amsterdam, Netherlands",
                "srv_country": "NL",
                "srv_latitude": "52.3730796",
                "srv_longitude": "4.8924534001",
                "srv_contact_first_name": "Erik",
                "srv_contact_last_name": "va******",
                "srv_contact_company": "Honeywell",
                "srv_contact_email": "ukclpvckr@ljxpbkxdc.com",
                "srv_contact_phone": "3737510925"
            },
            {
                "srv_id": 61821,
                "srv_name": "SERVF325",
                "srv_location": "Antwerpen, Belgium",
                "srv_country": "BE",
                "srv_latitude": "51.2211097",
                "srv_longitude": "4.3997081",
                "srv_contact_first_name": "Peter",
                "srv_contact_last_name": "Ho******",
                "srv_contact_company": "BASF",
                "srv_contact_email": "bevournxq@duxuswupr.com",
                "srv_contact_phone": "1126588944"
            },
            {
                "srv_id": 51565,
                "srv_name": "SERVG461",
                "srv_location": "Antwerpen, Belgium",
                "srv_country": "BE",
                "srv_latitude": "51.2211097",
                "srv_longitude": "4.3997081",
                "srv_contact_first_name": "Peter",
                "srv_contact_last_name": "Ho******",
                "srv_contact_company": "BASF",
                "srv_contact_email": "elmdagbmx@kitbbbhzb.com",
                "srv_contact_phone": "4144899098"
            },
            {
                "srv_id": 60646,
                "srv_name": "SERVF863",
                "srv_location": "Antwerpen, Belgium",
                "srv_country": "BE",
                "srv_latitude": "51.2211097",
                "srv_longitude": "4.3997081",
                "srv_contact_first_name": "Thijs",
                "srv_contact_last_name": "Ge******",
                "srv_contact_company": "BASF",
                "srv_contact_email": "tbtekqzpg@bfayqaprl.com",
                "srv_contact_phone": "1989869825"
            },
            {
                "srv_id": 15413,
                "srv_name": "Total Refinery Antwerpen",
                "srv_location": "Antwerpen, Belgium",
                "srv_country": "BE",
                "srv_latitude": "51.2211097",
                "srv_longitude": "4.3997081",
                "srv_contact_first_name": "Jo",
                "srv_contact_last_name": "Va******",
                "srv_contact_company": "Total Refinery",
                "srv_contact_email": "dfxjaadxk@zmcqqvdgy.com",
                "srv_contact_phone": "9624320158"
            },
            {
                "srv_id": 15104,
                "srv_name": "SERVD550",
                "srv_location": "Antwerpen, Belgium",
                "srv_country": "BE",
                "srv_latitude": "51.2211097",
                "srv_longitude": "4.3997081",
                "srv_contact_first_name": "Thijs",
                "srv_contact_last_name": "Ge******",
                "srv_contact_company": "BASF",
                "srv_contact_email": "eyxistmrz@pgksuijxh.com",
                "srv_contact_phone": "9027051381"
            },
        ]
    }

    async function drilldown(e) {
        if (!e.seriesOptions) {
            const chart = this,
                mapKey = `countries/us/${e.point.drilldown}-all`;

            // Handle error, the timeout is cleared on success
            let fail = setTimeout(() => {
                if (!Highcharts.maps[mapKey]) {
                    chart.showLoading(`
                        <i class="icon-frown"></i>
                        Failed loading ${e.point.name}
                    `);
                    fail = setTimeout(() => {
                        chart.hideLoading();
                    }, 1000);
                }
            }, 3000);

            // Show the Font Awesome spinner
            chart.showLoading('<i class="icon-spinner icon-spin icon-3x"></i>');

            // Load the drilldown map
            const topology = await fetch(
                `https://code.highcharts.com/mapdata/${mapKey}.topo.json`
            ).then(response => response.json());

            const data = Highcharts.geojson(topology);

            // Set a non-random bogus value
            data.forEach((d, i) => {
                d.value = i;
            });

            // Apply the recommended map view if any
            chart.mapView.update(
                Highcharts.merge(
                    {
                        insets: undefined,
                        padding: 0
                    },
                    topology.objects.default['hc-recommended-mapview']
                )
            );

            // Hide loading and add series
            chart.hideLoading();
            clearTimeout(fail);
            chart.addSeriesAsDrilldown(e.point, {
                name: e.point.name,
                data,
                dataLabels: {
                    enabled: true,
                    format: '{point.name}'
                }
            });
        }
    };

    function afterDrillUp(e) {
        if (e.seriesOptions.custom && e.seriesOptions.custom.mapView) {
            e.target.mapView.update(
                Highcharts.merge(
                    { insets: undefined },
                    e.seriesOptions.custom.mapView
                ),
                false
            );
        }
    };

    const countryGeometry = (a2) => {
        const country = geojson.features.find(f => {
            if (f.properties['hc-key'] === a2)
                return f;
        }).geometry; //Return Polygon Coordinats for Zooming
        return country
    }

    async function render(sites) {

        chart = Highcharts.mapChart(mapContainer, {
            chart: {
                map: topology,
                backgroundColor: "none",
                // zoomType: 'xy',
                panning: {
                    enabled: true,
                    type: 'xy'
                },
                events: {
                    render(ev) {
                        // console.log("Event render", ev)
                        // console.log("Render mapView", this.mapView)
                    },
                    redraw(ev) {
                        // console.log("Event redraw", ev)
                    }
                }
            },

            title: {
                text: 'Forge World Map Sites'
            },

            subtitle: {
                text: 'Source map: <a href="http://code.highcharts.com/mapdata/custom/world-continents.topo.json">World continents</a>'
            },

            tooltip: {
                useHTML: true,
                formatter() {
                    //Cluster point
                    if (this.point?.clusteredData) {
                        const html = `
                        <b>${this.series.name}</b><br>
                        VSE: ${this.point.clusterPointsAmount}`;
                        return html;
                    }
                    //Single site point
                    else if (this.point?.lat){
                        //Check risk color
                        const classBadge = `${this.point.srvRiskScore.toLowerCase()}-badge`;
                        return `
                        <ul class="ul-tooltip">
                            <li>
                            ${this.point.srvLocation}<br />
                            ${this.key} <div class="risk-badge ${classBadge}">${this.point.srvRisk}</div>
                            </li>
                        </ul>
                        `;
                    }
                    return false
                }
            },

            mapView: {
                // fitToGeometry: countryGeometry(), //1.
                // padding: 15,                      //2.
                // center: [25, 25],                 //3.
                // zoom: 3,                          //4.
                // maxZoom: 12
            },

            mapNavigation: {
                enabled: true,
                // enableDoubleClickZoomTo: true,
                enableButtons: false,
                enableMouseWheelZoom: false,
            },

            legend: {
                enabled: false,
                symbolRadius: 0,
                symbolHeight: 14,
            },

            plotOptions: {
                mappoint: {
                    cluster: {
                        enabled: true,
                        allowOverlap: true,
                        minimumClusterSize: 2,
                        animation: {
                            duration: 450
                        },
                        layoutAlgorithm: {
                            type: 'optimalizedKmeans'
                            // type: 'grid',
                            // gridSize: 40
                        },
                        marker: {
                            fillColor: 'rgba(219, 60, 48, 1)',
                            radius: 13
                        },
                        zones: [{
                            from: 1,
                            to: 4,
                            marker: {
                                radius: 13
                            }
                        }, {
                            from: 5,
                            to: 9,
                            marker: {
                                radius: 15
                            }
                        }, {
                            from: 10,
                            to: 15,
                            marker: {
                                radius: 17
                            }
                        }, {
                            from: 16,
                            to: 20,
                            marker: {
                                radius: 19
                            }
                        }, {
                            from: 21,
                            to: 100,
                            marker: {
                                radius: 21
                            }
                        }],
                        dataLabels: {
                            format: undefined,
                            formatter() {
                                // Cluster point
                                // console.log("Cluster point", this.point)
                                return this.point?.clusterPointsAmount
                            },
                            style: {
                                fontSize: '10px',
                                color:'#ffffff',
                                textOutline: 'transparent',
                                fontWeight: 'normal'
                            },
                            y: 0,
                            x: 0
                        },
                        events: {
                            drillToCluster(ev){
                                const cluster = this;
                                const ch = chart;
                                // console.log('drillToCluster -> Chart', ch)
                                console.log('drillToCluster -> Cluster', cluster)
                                console.log('drillToCluster -> Event Point', ev)
                                // const cords = chart.mapView.pixelsToLonLat({ x: chart.plotLeft + 45, y: chart.plotTop + 20 });
		                        // chart.series[1].addPoint({ ...cords });
                            }
                        }
                    }
                },
                series: {
                    states: {
                        inactive: {
                            opacity: 1
                        }
                    },
                    point: {
                        events: {
                            click() {
                                createPointLabel(this)
                            }
                        }
                    }
                },
            },

            series: [
            {
                id: 'world-map',
                allAreas: false,
                type: "map",
                name: 'World Map',
                joinBy: 'hc-key',
                color: 'rgba(244, 244, 242, 0.85)',
                nullColor: 'rgba(244, 244, 242, 0.3)',
                borderColor: '#d5d5d3',
                enableMouseTracking: true, //disable tooltips for specific series
                events: {
                    load() {
                        // chart.render();
                    },
                    click(e) {
                        e.point.zoomTo();
                        chart.render()
                    }
                },
                dataLabels: {
                    enabled: true,
                    inside: true,
                    allowOverlap: false,
                    format: '{point.name}',
                    style: {
                        color: '#6e6e6e',
                        textOutline: 'transparent',
                        fontWeight: 'normal'
                      }
                },
                data: dataCountries,
                // mapData: topology,
            },
            {
                id: 'map-point',
                type: 'mappoint',
                colorKey: 'clusterPointsAmount',
                name: 'Sites',
                enableMouseTracking: true,
                marker: {
                  width: 35,
                  height: 35,
                  symbol: 'url(/app/widgets/w_Dashboards/widgetImages/pin-gray.png)'
                },
                dataLabels: {
                    enabled: true,
                    format: undefined,
                    nullFormat: false,
                    formatter() {
                        // Single point not show Label
                        return this.point?.clusterPointsAmount
                    },
                },
                data: sites
            }
        ]
        });

        chart.render()

        if(isDebug) {
            console.log("map.js - render -> InstWidget: ", chart)
            console.log("map.js - render -> dataPointers: ", dataPointers)
        }

        console.log( Highcharts.geojson(geojson, 'mapline'))
    }

    //---- Once

    //---- Buttons
    function bindFooterEvents() {
        _btnZoomReset.addEventListener('click', () => {
            chart.mapView.zoomBy();
        })

        _btnZoomIn.addEventListener('click', () => {
            chart.mapView.zoomBy(0.9)
        })

        _btnZoomOut.addEventListener('click', () => {
            chart.mapView.zoomBy(-1.1)
        })

        _btnZoomBelgium?.addEventListener('click', function () {
            chart.get('be').zoomTo();
        });
    }

    //---- Point LABEL
    function createPointLabel(self) {
        // Show click only map point
        if(self.series?.userOptions.id === 'world-map' || !self.name) return;

        const _text = `<b>Clicked point</b><br>Series: ${self.series.name}
        <br>Point: ${self.srvName} (lat: ${self.lat} lon:${self.lon})`;

        const { chart } = self.series;

        // console.log(chart)

        const {x: chX, y: chY, width: chWidth, height: chHeight} = chart.plotBox


        if (chart.pointLabel) {
            chart.pointLabel?.destroy()
            chart.pointLabel = undefined;
        }

        const { renderer } = chart

        const groupLabel = renderer.g().add().toFront();

        renderer.label(_text, (chWidth - 285), chY)
        .css({
            width: '380px',
        })
        .attr({
            fill: '#FFFFEF',
            stroke: 'gray',
            'stroke-width': 1,
            zIndex: 4,
        })
        .add(groupLabel).toFront();

        const {width: grWidth, x: grX, y: grY} = groupLabel.getBBox()

        const text = renderer.text('x', (grX + grWidth) - 14, grY + 12)
        .css({
            fontSize: '14px'
        })
        .attr({
            zIndex: 5,
            cursor: 'pointer'
        })
        .on('click', () => {
            chart.pointLabel?.destroy();
            chart.pointLabel = undefined;
        })
        .add(groupLabel);


        chart.pointLabel = groupLabel

    }

    //---- Click on Risk Legends
    async function renderByRiskSites(key = '') {
        currentMap = key === currentMap ? '' : key
        const sites = await mapPointsSliceByRisk(currentMap)
        await render(sites);
    }

    function mapPointsSliceByRisk(risk = '') {
        if (!dataPointers) return;

        if (!risk) return dataPointers;

        return dataPointers.filter((srv) => {
            if(srv.srvRiskScore.toLowerCase() === risk.toLowerCase())
                return srv
        })
    }

    function searchSites(str) {
        const re = new RegExp(`.?(${str}).?`);
        const searchResult = dataPointers.filter((srv) => {
            const _srvName = srv.name.toLowerCase()
            if(re.test(_srvName))
                return srv;
        })

        render(searchResult);
    }

    function prepareData(data) {

        const _data = data.map((item) => {

        const srvRiskScore = getRandomArrItem()
        let srvRisk = generateRiskRandom()
        let _lat = item.srv_latitude
        let _lon = item.srv_longitude
        let _srvId = item.srv_id

        const isSameCoordinates = checkSameCoordinate(data, _srvId, _lat, item.srv_longitude)

            if (isSameCoordinates) {
                _lat = `${_lat.slice(0, -1)}${generateRiskRandom(2)}`
                _lon = `${_lon.slice(0, -1)}${generateRiskRandom(2)}`
            }

            switch (srvRiskScore) {
                case 'H':
                    hRisk ++
                    break;
                case 'M':
                    mRisk ++
                    break;
                case 'L':
                    lRisk ++
                    break;
                default:
                    noRisk ++
                    srvRisk = 0
                    break;
            }

            return {
                lat: Number(_lat), //new field
                lon: Number(_lon), //new field
                name: item.srv_name,
                marker: converter.pointMarker(srvRiskScore),
                srvId: item.srv_id,
                srvLocation: item.srv_location,
                srvCountry: item.srv_country.toLowerCase(), //new field
                srvFirstName: item.srv_contact_first_name,
                srvLastName: item.srv_contact_last_name,
                srvCompany: item.srv_contact_company,
                srvEmail: item.srv_contact_email,
                srvPhone: item.srv_contact_phone,
                srvRiskScore,
                srvRisk,
                srvStatus: 'up'
            }
        })

        return _data
    }

    function checkSameCoordinate(data, srvId, lat, lon) {
        console.log(data, lat, lon)
        const _ext = data.some((item) => {
            // console.log(item, srvId, item.srv_latitude === lat, item.srv_longitude === lon)
            return (srvId !== item.srv_id && (item.srv_latitude === lat && item.srv_longitude === lon))
        })

        return _ext
    }

    function animateRiskScore() {
        const elRiskH = document.querySelector(`#${mapId}-risk-h`);
        const elRiskM = document.querySelector(`#${mapId}-risk-m`);
        const elRiskL = document.querySelector(`#${mapId}-risk-l`);
        const elRiskN = document.querySelector(`#${mapId}-risk-n`);

        {
            let toH = 0;
            let toM = 0;
            let toL = 0;
            let toN = 0;
            const countsH = setInterval(() => {
                elRiskH.innerHTML = ++toH
                if (toH === hRisk)
                    clearInterval(countsH);

            })
            const countsM = setInterval(() => {
                elRiskM.innerHTML = ++toM
                if (toM === mRisk)
                    clearInterval(countsM);

            })
            const countsL = setInterval(() => {
                elRiskL.innerHTML = ++toL
                if (toL === lRisk)
                    clearInterval(countsL);

            })
            const countsN = setInterval(() => {
                elRiskN.innerHTML = ++toN
                if (toN === noRisk)
                    clearInterval(countsN);

            })

        }
    }

    function getSitesByCountry() {

    }

    Init()

    return {
        mapId,
        renderMap: renderByRiskSites,
        searchSites
    }
}

const arrRisk = ['H', 'M', 'L', 'N']

function generateRiskRandom(maxLimit = 100){
    const rand = Math.random() * maxLimit; // say 99.81321410836433
    return Math.floor(rand); // 99
}

function getRandomArrItem(arr = arrRisk) {
    // get random index value
    const randomIndex = Math.floor(Math.random() * arr.length);

    // get random item
    const item = arr[randomIndex];

    return item;
}

function RiskParamsConverter() {
    return {
        siteRiskColor(data) {
            const Colors = {
                H: '#D60B13',
                M: '#FFC527',
                L: '#279D2B',
                D: '#B0B0B0'
            }
            return Colors[data] ? Colors[data] : ''
        },
        pointMarker(srvRiskScore) {
            switch (srvRiskScore) {
                case 'H':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-red.png)'
                    }
                case 'M':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-yellow.png)'
                    }
                case 'L':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-green.png)'
                    }
                default:
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-gray.png)'
                    }
            }
        },
        riskSeverity(sev) {
            const riskSeverity = {
                L: "Low",
                M: "Medium",
                H: "High"
            }
            return riskSeverity[sev] ? riskSeverity[sev] : '';
        }
    }
}

const converter = RiskParamsConverter()
