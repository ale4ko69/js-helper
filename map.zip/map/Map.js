import "/assets/map/@highcharts/js/highmaps.js";
import '/assets/map/@highcharts/js/modules/data.js';
import '/assets/map/@highcharts/js/modules/drilldown.js';
import '/assets/map/@highcharts/js/modules/exporting.js';
import '/assets/map/@highcharts/js/modules/marker-clusters.js';
import Searcher from './Searcher.js';
import sheets from "./style.css" assert { type: 'css' };

document.componentRegistry = {};
document.nextId = 0;

/**
 * Usage
    <textarea onchange="document.componentRegistry[${this._id}].setBody(this.value)">
    ${this.state.body}
    </textarea>

    Updating in response to state changes
    var blogPost = new BlogPost(blogPostData);
    function update() {
        document.querySelector('body').innerHTML = blogPost.render();
    }
 */
class Component {
  constructor() {
    this._id = ++document.nextId;
    document.componentRegistry[this._id] = this;
  }
}
export class Map extends Component {

    //#region ---- Class Properties
    SCApp           = false //---- If module work in the Security Center environment
    Highcharts      = null  //---- Highcharts Instance
    self            = this

    //---- Default Paths
    urlEpMap        = '/assets/map/@highcharts/map-collection'  //---- A constantly path for maps
    urlDefaultMap   = '/custom/world-highres2.topo.json'        //---- A default World Map

    //---- DOM ELEMENTS
    _rootDom         = null  //---- A DOM Root Element for the Map
    _mapContainer
    _mapHeader
    _mapFooter
    _infoPanel
    _btnClose
    _btnZoomRes
    _btnZoomIn
    _btnZoomOut
    _inpSearch
    _btnReload
    _btnSearch


    //---- Map Chart Instance
    chart

    mapId               //---- Map Wrapper ID
    headerId            //---- Map Header Wrapper ID
    footerId            //---- Map Footer Wrapper ID

    //---- Risks Statistic
    riskStatistic = {
        H: 0,
        M: 0,
        L: 0,
        N: 0
    }

    //---- Sites Status Statistic
    statusStatistic = {
        down: 0,
        up: 0,
        offline: 0,
        manual: 0
    }

    //---- Sites without Coordinates Statistic
    sitesLonLatStatistic = 0

    //---- Total Statistic
    sitesTotalCounts = 0

    //---- Risk Counter Amounts for Animation
    countsH
    countsM
    countsL
    countsN

    //---- Type of rendered info panel
    panelType = {
        'CLUSTER'       : 'Cluster',
        'SITE'          : 'Site',
        'CLUSTER_SITE'  : 'Cluster_Site'
    }

    riskMap = ['H', 'M', 'L', 'N']

    siteStatus = {
        down: "down",
        up: "up",
        offline: "offline",
        manual: "manual"
    }

    options = {
        oRootDom: '',
        searchPanelDOM: '',
        title: 'Sites Map',
        debug: false,
        children: [],
        search: {},
        shadow: false
    }

    //#endregion

    //---- STATE
    state = {
        worldMap                : null,     //---- World Map Data Object
        geojson                 : null,     //---- Geo JSON Map Object
        dataPointers            : null,
        dataCountries           : null,
        currentRiskMap          : [],       //---- Current selected Map risks
        currentPointers         : [],       //---- Current selected Sites List
        lastClusterPoints       : [],       //---- Last Cluster Sites List
        isMaxZoom               : false,    //---- If a Map Zoom is getting Maximum
        currentPanel            : '',       //---- Type String from one of panelType
        isOuterSearch           : false,    //---- If search Panel used from out of the Map widget
        showDownSites           : false
    }

    constructor(props = {}) {
        super();

        this.options = Object.assign({}, this.options, props)
        this.state.isOuterSearch = (props?.search && !this.isObjEmpty(props?.search)) ? true : false
        this.SCApp = !!globalThis.HOME_PAGE_APP
        this.isDebug = this.options.debug
        this.children = this.options.children;
        this.Highcharts = Highcharts
        this._rootDom = this.$(this.options.oRootDom)

        //---- Reset Zoom Button
        this.Highcharts.wrap(Highcharts.Chart.prototype, 'showResetZoom', (proceed) => {})

        //---- Render ID for Map Widget
        const rndID = this.generateNumRandom(1000)
        this.mapId  = `map-${rndID}`
        this.headerId = `header-${rndID}`
        this.footerId = `footer-${rndID}`

        //---- Insert Map Component to the DOM
        if(this.options.shadow){
            this.shadowRoot = this._rootDom.attachShadow({mode: "open"});
            this.shadowRoot.adoptedStyleSheets = [sheets];
            this.shadowRoot.innerHTML = this.getRootTmpl()
        } else {
            document.adoptedStyleSheets = [sheets];
            this._rootDom.innerHTML = this.getRootTmpl()
        }

        //---- New Instance Functions Data converter
        this.converter = RiskParamsConverter()

        //---- Searcher Component
        const searcherParams = this.state.isOuterSearch ? {
            searchBoxDOM: this.$(this.options.search.searchBoxDOM),
            shadowRoot: this.shadowRoot
        } : {
            shadowRoot: this.shadowRoot
        }

        //---- Init new Searcher
        this.searcher  = new Searcher(this, searcherParams)


        this._mapContainer = this.$(`#${this.mapId} .map__inner`)

        this._mapFooter = this.$(`#${this.mapId} .map-footer`)

        //---- Bind Buttons Events
        this.bindWidgetEvents()

        this.Init()
    }

    async Init() {
        try {

            //---- Load World Map
            await this.getWorldMap()

            //---- Load Countries
            const _dataCountries = await this.getDataCountries()

            this.setDataCountries(_dataCountries)

            // TODO Get Sites data from server
            const _dataPointers = await import('/assets/map/full-sites-data.js')
            // TODO Prepare Data Object fot the Map
            // dataPointers = prepareData(getFullSites());
            this.setDataPointers(_dataPointers.default)

            //---- Count Risk Score
            this.countSitesStatistic()

            //Render Chart
            await this.renderByRiskSites()

            //---- Create Risk Score Legends
            this.animateStatisticScore()

        } catch (err) {
            console.log(err)
        }
    }

    //#region EVENTS
    bindWidgetEvents() {

        this._btnZoomReset = this.$(`#${this.mapId}-zoomReset`)
        this._btnZoomIn = this.$(`#${this.mapId}-zoomIn`)
        this._btnZoomOut = this.$(`#${this.mapId}-zoomOut`)

        this._btnZoomReset.addEventListener('click', () => {
            this.closeAllInfoPanel()
            this.chart.mapView.zoomBy()
        })

        this._btnZoomIn.addEventListener('click', () => {
            this.closeAllInfoPanel()
            this.chart.mapView.zoomBy(0.9)
        })

        this._btnZoomOut.addEventListener('click', () => {
            this.closeAllInfoPanel()
            this.chart.mapView.zoomBy(-1.1)
        })

        // window.addEventListener(customEvents.selectedOption)
        // this._btnReload.addEventListener('click', () => {
        //     this.reload()
        // })

        // this._btnSearch.addEventListener('click', () => {
        //     this.showSearchBox()
        // })

        // this._inpSearch.addEventListener('blur', () => {
        //     this.hideSearchBox()
        // })

        // this._inpSearch.addEventListener('keyup', this.debounce((ev) => {
        //     const value = ev.target.value
        //     this.closeAllInfoPanel()
        //     this.chart.mapView.zoomBy()
        //     this.searcher.find(this.state.currentPointers, value)

        // }, 450))

        // this._inpSearch.addEventListener('blur', (ev) => {
        //     ev.target.value = ""
        // })
    }

    //#endregion

    //#region ---- STATE SET
    setDataPointers(data) {
        this.state.dataPointers = data
    }

    setDataCountries(data) {
        this.state.dataCountries = data
    }

    setIsMaxZoom(data) {
        this.state.isMaxZoom = data
    }

    setWorldMap(data) {
        this.state.worldMap = data
    }

    setGeojson(data) {
        this.state.geojson = data
    }

    setCurrentMap(data) {
        this.state.currentRiskMap = data
    }
    //#endregion

    //#region ---- GET DATA FUNCTIONS

    //---- Get World Map
    async getWorldMap(epMap) {
        const url = epMap ?? this.urlDefaultMap
        const worldMap = await fetch(`${this.urlEpMap}${url}`).then((response) => response.json())

        this.setWorldMap(worldMap)
        this.setGeojson(Highcharts.topo2geo(worldMap))

        if (this.isDebug) {
            console.log('map.js - getTopology -> topology', this.state.worldMap)
            console.log('map.js - getTopology -> geojson', this.state.geojson)
        }

        return this.state.worldMap
    }

    async getSiteInfo(siteId) {
       return new Promise((resolve, reject) => {
            this.Highcharts.ajax({
                url: `/assets/map/db.js?siteId=${siteId}`, //TODO Change to service end point
                type: 'GET',
                dataType: 'json',
                success(data){
                    resolve(data)
                },
                error(err){
                    reject(err)
                }
            })
       })
    }

    //#endregion

    //#region ---- Prepare Data

    countSitesStatistic() {
        //---- Count Risk Score
        this.sitesTotalCounts = this.state.dataPointers.length;

        this.state.dataPointers.forEach((item) => {

            if (item.srvRiskScore === 'N') {
                item.srvRisk = 0
            }

            this.riskStatistic[item.srvRiskScore] ++

            if(item.srvStatus) {
                this.statusStatistic[item.srvStatus] ++
            }

            if(!item.lat || !item.lon) {
                this.sitesLonLatStatistic ++
            }


        })

        if(this.isDebug) {
            console.log(`this.statusStatistic =>`, this.statusStatistic)
            console.log(`this.riskStatistic =>`, this.riskStatistic)
            console.log(`this.sitesLonLatStatistic =>`, this.sitesLonLatStatistic)
        }
    }

    getCountryFeature = (a2) => {
        const _geojson = this.state.geojson;

        const _country = _geojson.features.find((f) => {
            if (f.properties['hc-key'] === a2) return f
        })
        return _country
    }

    async getDataCountries(url) {
        //TODO GET FROM SERVER
        // Prepare demo data. The data is joined to map using value of 'hc-key'
        // property by default. See API docs for 'joinBy' for more info on linking
        // data and map.
        const _data = [
            ['fo', 0],
            // ["um", 1],
            ['us', 2],
            ['jp', 3],
            ['sc', 4],
            ['in', 5],
            ['fr', 6],
            // ["fm", 7],
            ['cn', 8],
            ['pt', 9],
            ['sw', 10],
            ['sh', 11],
            ['br', 12],
            // ["ki", 13],
            ['ph', 14],
            ['mx', 15],
            ['es', 16],
            ['bu', 17],
            ['mv', 18],
            ['sp', 19],
            ['gb', 20],
            ['gr', 21],
            // ["as", 22],
            ['dk', 23],
            ['gl', 24],
            // ["gu", 25],
            ['mp', 26],
            ['pr', 27],
            ['vi', 28],
            ['ca', 29],
            ['st', 30],
            ['cv', 31],
            ['dm', 32],
            ['nl', 33],
            ['jm', 34],
            // ["ws", 35],
            ['om', 36],
            ['vc', 37],
            ['tr', 38],
            ['bd', 39],
            ['lc', 40],
            // ["nr", 41],
            ['no', 42],
            ['kn', 43],
            ['bh', 44],
            // ["to", 45],
            ['fi', 46],
            ['id', 47],
            ['mu', 48],
            ['se', 49],
            ['tt', 50],
            ['my', 51],
            ['pa', 52],
            // ["pw", 53],
            // ["tv", 54],
            // ["mh", 55],
            ['cl', 56],
            ['th', 57],
            ['gd', 58],
            ['ee', 59],
            ['ag', 60],
            ['tw', 61],
            ['bb', 62],
            ['it', 63],
            ['mt', 64],
            // ["vu", 65],
            ['sg', 66],
            ['cy', 67],
            ['lk', 68],
            ['km', 69],
            // ["fj", 70],
            ['ru', 71],
            ['va', 72],
            ['sm', 73],
            ['kz', 74],
            ['az', 75],
            ['tj', 76],
            ['ls', 77],
            ['uz', 78],
            ['ma', 79],
            ['co', 80],
            ['tl', 81],
            ['tz', 82],
            ['ar', 83],
            ['sa', 84],
            ['pk', 85],
            ['ye', 86],
            ['ae', 87],
            ['ke', 88],
            ['pe', 89],
            ['do', 90],
            ['ht', 91],
            ['pg', 92],
            ['ao', 93],
            ['kh', 94],
            ['vn', 95],
            ['mz', 96],
            ['cr', 97],
            ['bj', 98],
            ['ng', 99],
            ['ir', 100],
            ['sv', 101],
            ['sl', 102],
            ['gw', 103],
            ['hr', 104],
            ['bz', 105],
            ['za', 106],
            ['cf', 107],
            ['sd', 108],
            ['cd', 109],
            ['kw', 110],
            ['de', 111],
            ['be', 112],
            ['ie', 113],
            ['kp', 114],
            ['kr', 115],
            ['gy', 116],
            ['hn', 117],
            ['mm', 118],
            ['ga', 119],
            ['gq', 120],
            ['ni', 121],
            ['lv', 122],
            ['ug', 123],
            ['mw', 124],
            ['am', 125],
            ['sx', 126],
            ['tm', 127],
            ['zm', 128],
            ['nc', 129],
            ['mr', 130],
            ['dz', 131],
            ['lt', 132],
            ['et', 133],
            ['er', 134],
            ['gh', 135],
            ['si', 136],
            ['gt', 137],
            ['ba', 138],
            ['jo', 139],
            ['sy', 140],
            ['mc', 141],
            ['al', 142],
            ['uy', 143],
            ['cnm', 144],
            ['mn', 145],
            ['rw', 146],
            ['so', 147],
            ['bo', 148],
            ['cm', 149],
            ['cg', 150],
            ['eh', 151],
            ['rs', 152],
            ['me', 153],
            ['tg', 154],
            ['la', 155],
            ['af', 156],
            ['ua', 157],
            ['sk', 158],
            ['jk', 159],
            ['bg', 160],
            ['qa', 161],
            ['li', 162],
            ['at', 163],
            ['sz', 164],
            ['hu', 165],
            ['ro', 166],
            ['ne', 167],
            ['lu', 168],
            ['ad', 169],
            ['ci', 170],
            ['lr', 171],
            ['bn', 172],
            ['iq', 173],
            ['ge', 174],
            ['gm', 175],
            ['ch', 176],
            ['td', 177],
            ['kv', 178],
            ['lb', 179],
            ['dj', 180],
            ['bi', 181],
            ['sr', 182],
            ['il', 183],
            ['ml', 184],
            ['sn', 185],
            ['gn', 186],
            ['zw', 187],
            ['pl', 188],
            ['mk', 189],
            ['py', 190],
            ['by', 191],
            ['cz', 192],
            ['bf', 193],
            ['na', 194],
            ['ly', 195],
            ['tn', 196],
            ['bt', 197],
            ['md', 198],
            ['ss', 199],
            ['bw', 200],
            ['bs', 201],
            ['nz', 202],
            ['cu', 203],
            ['ec', 204],
            ['au', 205],
            ['ve', 206],
            ['sb', 207],
            ['mg', 208],
            ['is', 209],
            ['eg', 210],
            ['kg', 211],
            ['np', 212],
        ]
        return _data
    }

    //---- Slice Data by Risk Score
    mapPointsSliceByRisk() {
        if (!this.state.dataPointers) return
        const _currentRiskMap = this.state.currentRiskMap

        const result = this.state.dataPointers.filter((srv) => {

            if (this.state.showDownSites){
                if (srv.srvStatus === this.siteStatus.down) return srv
            } else if (_currentRiskMap.includes(srv.srvRiskScore)) return srv
        })

        this.state.currentPointers = [...result]

        return result
    }

    createCountCountries(countryCode, _arrCountries = []) {

        //---- Countires more...
        const { name } = this.getCountryFeature(countryCode).properties

        const _currentCountry = _arrCountries.find((item) => {
            if (item?.code === countryCode) return item
        })

        if (_currentCountry) {
            _currentCountry.count ++
        } else {
            _arrCountries.push({
                name,
                code: countryCode,
                count: 1,
            })
        }
        //---- End Countries More

        return _arrCountries
    }

    //TODO Remove ---- Search Site by Name (min 3 chars)
    searchSites(str) {

        if (this.isDebug) {
            console.log(`Method searchSites: search string: ${str}`)
        }

        const re = new RegExp(`.?(${str}).?`, 'i')
        const _sites = [...this.state.currentPointers]

        if (str.length === 0) {
            this.render(_sites)
            return
        }

        //Find Sites by text in
        const searchResult = _sites.filter((srv) => {
            if (re.test(srv.name)) return srv
        })

        this.render(searchResult)
    }

    //#endregion

    //#region ---- RENDER FUNCTIONS

    //---- Render Map by Risk
    async renderByRiskSites(payload = {}) {
        const { key, selected } = payload

        if(this.isDebug){
            console.log(`renderByRiskSites key: ${key}`)
        }

        const _riskMap = [...this.riskMap];
        let _currentRiskMap = [...this.state.currentRiskMap];

        //---- Show Full Ponts Map
        if (!key) {
            _currentRiskMap = _riskMap
        }
        //---- Show only Sites with status DOWN
        else if (key === this.siteStatus.down) {
            _currentRiskMap = _riskMap
            this.state.showDownSites = !this.state.showDownSites
        }
        else {
            //---- If clicked Risk is exists in the _currentRiskMap
            const indexScore = _currentRiskMap.indexOf(key)

            //---- If no -> append
            if (indexScore === -1) {
                _currentRiskMap.push(key)
            }
            else {
                //---- If current status is selected, filtered and show only this Risk
                if (selected) {
                    const filterd = _currentRiskMap.filter((item) => item === key)
                    _currentRiskMap = filterd
                }
                //---- If not selected, remove from current RiskMap
                else {
                    _currentRiskMap.splice(indexScore, 1)
                }

                //---- If _currentRiskMap is empty -> show full map
                if(_currentRiskMap.length === 0) {
                    _currentRiskMap = _riskMap
                }
            }
        }

        this.setCurrentMap(_currentRiskMap)

        const sites = await this.mapPointsSliceByRisk()

        this.toggleRiskLinks()

        return await this.render(sites)
    }

    async renderByStatus(key = 'down') {

        this.state.showDownSites = !this.state.showDownSites
        this.setCurrentMap([...this.riskMap])

        const sites = await this.mapPointsSliceByRisk()
        return await this.render(sites)
    }

    renderTooltipCluster(clusterData) {

        const _arrLI        = []
        const _moreSites    = []
        let _arrCountries

        if (Array.isArray(clusterData) && clusterData.length > 0) {

            clusterData.forEach((item, index) => {
                const { options: point } = item
                const { srvRiskScore, srvRisk, name, 'hc-key': hcKey } = point

                _arrCountries = this.createCountCountries(hcKey, _arrCountries)

                if (index >= 5) {
                    return;
                }

                //---- Check risk color
                const _classBadge = `${srvRiskScore.toLowerCase()}-badge`
                const _liTmpl = `<li class="cluster-item">
                        ${name} <div class="risk-badge ${_classBadge}">
                        ${srvRisk}</div></li>`

                //---- Append to list first 5 items
                _arrLI.push(_liTmpl)
            })
        }

        _arrCountries.forEach((item) => {
            _moreSites.push(`
                <span class="count-more"><b>${item.name}</b> (${item.count}); </span>`)
        })

        return `<ul class="ul-tooltip cluster">${_arrLI.join('')}
        <hr />
        ${_moreSites.join('')}</ul>`
    }

    renderTooltipSingle(point) {
         //TODO Change srvLocation to the Country Name, City & Address
         //---- Check risk color
         const _classBadge = `${point.srvRiskScore.toLowerCase()}-badge`
         return `
         <ul class="ul-tooltip">
             <li>
             ${point.name} <div class="risk-badge ${_classBadge}">${point.srvRisk}</div>
             </li>
             <hr />
             <span class="count-more"><b>${point.srvLocation}</span>
         </ul>
         `
    }

    async renderSitePanel(data, type) {
        const self = this
        const mapContainer = this.$(`#${this.mapId} .map-container`)
        let tmpl
        let panelInfo
        let panelBreadcrumbs
        let panelContent
        let panelFooter
        let closeBtn

        switch (type) {
            case this.panelType.CLUSTER:
                //---- Find Site Info Panel
                const panelSiteInfo = this.$(`#${this.mapId} .info__inner[data-paneltype='${this.panelType.SITE}']`)
                //---- Close & Remove Site Info Panel
                if (panelSiteInfo) {
                    const isPanel = await _closeInfoPanel(panelSiteInfo, true)
                    if(isPanel) {
                        panelSiteInfo.remove()
                    }
                }

                //---- DOMElement Info Cluster Panel - if exists
                panelInfo = this.$(`#${this.mapId} .info__inner[data-paneltype='${this.panelType.CLUSTER}']`)

                if (panelInfo?.length === 0) {
                    //---- Set Type of Panel
                    this.state.currentPanel = this.panelType.CLUSTER
                    //---- Set Cluster Site Points
                    this.state.lastClusterPoints = [...data]

                    //---- Get & Add Info Panel TMPL
                    tmpl = this.getSitePanelTmpl()
                    mapContainer.insertAdjacentHTML('beforeend', tmpl)

                    //---- DOMElement Info Panel
                    panelInfo = this.$(`#${this.mapId} .info__inner[data-paneltype='${this.panelType.CLUSTER}']`)
                }

                //---- Set Event Listener on the Panel Close Button
                closeBtn = panelInfo.querySelector(`.btn-close`)
                closeBtn.addEventListener('click', () => _closeInfoPanel(panelInfo))

                //---- DOMElement Breadcrumbs in the Header
                panelBreadcrumbs = this.$(`#${this.mapId} .site-breadcrumbs`)
                //---- DOMElement Content
                panelContent = this.$(`#${this.mapId} .panel__content`)
                //---- DOMElement Footer
                panelFooter = this.$(`#${this.mapId} .panel__footer`)

                //---- Clean Previous HTML
                panelBreadcrumbs.innerHTML = ""
                panelContent.innerHTML = ""
                panelFooter.innerHTML = ""

                //---- Append HTML to Header
                panelBreadcrumbs.append(...this.generateDOMHtml(this.getClusterHeaderHtml()))
                //---- Append HTML to Info Panel
                panelContent.append(...this.generateDOMHtml(this.getClustersHtml(data)))

                //---- Attach events for Site Info
                let arrows = panelContent.querySelectorAll(`.get-info-arrow`)
                arrows.forEach((arrow) => {
                    arrow.addEventListener('click', (ev) => {
                        const el = ev.target;
                        const { siteid } = el.dataset
                        self.renderSitePanel({srvId: siteid}, this.panelType.CLUSTER_SITE)
                    })
                })

                //---- Show Panel
                setTimeout(() => {
                    panelInfo.classList.add("show"), 150
                    // setTimeout(() => panelInfo.classList.add("resize"), 650)
                })
                break;

            case this.panelType.SITE:
            case this.panelType.CLUSTER_SITE:

                const isClusterSite = (type === this.panelType.CLUSTER_SITE) //Arrived from a Cluster

                //---- Remove Cluster Panel
                const panelClusterInfo = this.$(`#${this.mapId} .info__inner[data-paneltype='${this.panelType.CLUSTER}']`)

                if (panelClusterInfo) {

                    if(!isClusterSite){
                        //---- Clean state lastClusterPoints
                        this.state.lastClusterPoints = []
                    }

                    //---- Close Opened Cluster Panel
                    const isPanel = await _closeInfoPanel(panelClusterInfo, true)
                    //---- Remove from DOM
                    if(isPanel) {
                        panelClusterInfo.remove()
                    }
                }

                //---- Get Site Info from DB
                const response = await this.getSiteInfo(data.srvId)

                //TODO Delete finding for site
                const site = response.find((item) => {
                    return item.srvId === Number(data.srvId)
                })

                if (this.isDebug) {
                    console.log(`Render ${type}: ${data.srvId}; Data:`, site)
                }

                //---- DOMElement Info Panel - if exists
                panelInfo = this.$(`#${this.mapId} .info__inner[data-paneltype='${this.panelType.SITE}']`)

                //---- If not - create
                if (panelInfo?.length === 0) {
                    //---- Set Type of Panel
                    this.state.currentPanel = this.panelType.SITE
                    //---- Get & Add Info Panel TMPL
                    tmpl = this.getSitePanelTmpl()
                    mapContainer.insertAdjacentHTML('beforeend', tmpl)

                    //---- DOMElement Info Panel
                    panelInfo = this.$(`#${this.mapId} .info__inner[data-paneltype='${this.panelType.SITE}']`)
                }

                //---- Set Event Listener on the Panel Close Button
                closeBtn = panelInfo.querySelector(`.btn-close`)
                closeBtn.addEventListener('click', () => _closeInfoPanel(panelInfo))

                //---- DOMElement Breadcrumbs in the Header
                panelBreadcrumbs = this.$(`#${this.mapId} .site-breadcrumbs`)
                //---- DOMElement Content
                panelContent = this.$(`#${this.mapId} .panel__content`)
                //---- DOMElement Footer
                panelFooter = this.$(`#${this.mapId} .panel__footer`)

                //---- Clean Previous HTML
                panelBreadcrumbs.innerHTML = ""
                panelContent.innerHTML = ""
                panelFooter.innerHTML = ""

                //---- Append HTML to Header
                panelBreadcrumbs.append(...this.generateDOMHtml(this.getSiteHeaderHtml(site)))
                //---- Append HTML to Info Panel
                panelContent.append(...this.generateDOMHtml(this.getSiteHtml(site)))

                //---- Add HTML to footer if type is CLUSTER_SITE
                if(isClusterSite){
                    panelFooter.innerHTML = `<a href="javascript:void(0)" class="back-arrow-link" onclick="document.componentRegistry[${this._id}].backToClusterPanel()">Back</div>`
                }

                //---- Show Panel
                setTimeout(() => {
                    panelInfo.classList.add("show")

                    // setTimeout(() => panelInfo.classList.add("resize"), 650)

                }, 150)

                break;
        }

        function _closeInfoPanel(panelInfo, _removehard = false) {

            return new Promise((resolve) => {
                if(!panelInfo || panelInfo?.length === 0) {
                    resolve(false)
                    return
                }

                if (panelInfo.classList.contains('show') || _removehard){
                        panelInfo.classList.remove('show')
                        // panelInfo.classList.remove("resize")
                    setTimeout(() => resolve(true), 500)
                }
            })
        }
    }

    backToClusterPanel() {
        this.renderSitePanel([...this.state.lastClusterPoints], this.panelType.CLUSTER)
    }

    async reload() {
        //Reset Map to default Zoom
        this.chart.mapView.zoomBy()
        this.clearStatistic()

        // TODO Get Sites data from server
        const _dataPointers = await import('/assets/map/full-sites-data.js')
        // TODO Prepare Data Object fot the Map
        // dataPointers = prepareData(getFullSites());
        this.setDataPointers(_dataPointers.default)

        //---- Count Risk Score
        this.countSitesStatistic()

        //Render Chart
        await this.renderByRiskSites()

        //---- Create Risk Score Legends
        this.animateStatisticScore()
    }

    async render(sites) {

        //---- Update Map Points Data
        if(this.chart) {
            this.chart.series[2].visible = sites.length === 0 ? false : true;
            this.chart.series[2].setData(sites)
            this.chart.redraw();
            return;
        }

        const self = this
        const _options = {
            chart: {
                backgroundColor: 'none',
                margin: [0, 0, 0, 0],
                events: {
                    load(ev) {

                        if (self.isDebug) {
                            console.log("Event load", ev)
                        }

                        const mapView = this.mapView;
                        const points = this.series[2].points;
                        const maxLat = Math.max(...points.map(p => p.lat));
                        const maxLon = Math.max(...points.map(p => p.lon));
                        const minLat = Math.min(...points.map(p => p.lat));
                        const minLon = Math.min(...points.map(p => p.lon));

						 const maxLatLon = mapView.lonLatToProjectedUnits({
						 	lat: maxLat,
							lon: maxLon
						 });

						 const minLatLon = mapView.lonLatToProjectedUnits({
						 	lat: minLat,
							lon: minLon
						 });

						 const bounds = {
						 	x1: minLatLon.x,
							y1: minLatLon.y,
							x2: maxLatLon.x,
							y2: maxLatLon.y
						 };

						 mapView.fitToBounds(bounds, '5%');
                    },
                    render(ev) {
                        if (self.isDebug) {
                            console.log("Event render", ev)
                        }

                        setTimeout(self.setVisibleClusterAmount.bind(self), 150)

                        self.setIsMaxZoom(this.mapView.zoom === this.mapView.options.maxZoom)
                    },
                    redraw(ev) {
                         if (self.isDebug) {
                            console.log("Event redraw", ev)
                        }
                        self.paintCluster(this)
                    },
                },
            },

            tooltip: this.getChartTooltip(),

            mapView: {
                maxZoom: 10,
            },

            legend: {
                enabled: false,
                symbolRadius: 0,
                symbolHeight: 14,
            },

            mapNavigation: {
                enabled: true,
                enableButtons: false,
                enableMouseWheelZoom: true,
            },

            plotOptions: this.getChartPlotOptions(),

            series: [
                {
                    id: 'world-map',
                    allAreas: false,
                    type: 'map',
                    name: 'World Map',
                    joinBy: ['hc-key'],
                    color: 'rgba(244, 244, 242, 0.85)',
                    nullColor: 'rgba(244, 244, 242, 0.2)',
                    borderColor: 'rgba(0, 0, 0, 0)',
                    enableMouseTracking: false, //disable tooltips for specific series
                    dataLabels: {
                        enabled: true,
                        inside: true,
                        allowOverlap: false,
                        format: '{point.name}',
                        style: {
                            color: '#6e6e6e',
                            textOutline: 'transparent',
                            fontWeight: 'normal',
                        },
                    },
                    data: this.state.dataCountries,
                    mapData: this.state.worldMap,
                },
                {
                    name: 'Separators',
                    type: 'mapline',
                    nullColor: '#279D2B',
                    showInLegend: false,
                    enableMouseTracking: true,
                    accessibility: {
                        enabled: false,
                    },
                },
                {
                    id: 'map-point',
                    type: 'mappoint',
                    colorKey: 'clusterPointsAmount',
                    name: 'Sites',
                    joinBy: ['hc-key'],
                    enableMouseTracking: true,
                    allowPointSelect: true,
                    dataLabels: {
                        enabled: true,
                        format: undefined,
                        nullFormat: false,
                        formatter() {
                            //---- Single point not show Label
                            return this.point?.clusterPointsAmount
                        },
                    },
                    data: sites,
                },
            ],
        }

        Object.assign(_options, this.getDisabledChartOptions())

        this.chart = Highcharts.mapChart(this._mapContainer, _options)

        this.chart.redraw()

        if (this.isDebug) {
            console.log('map.js - render -> InstWidget: ', this.chart)
            console.log('map.js - render -> dataPointers: ', this.state.dataPointers)
        }

        return this.chart
    }

    //#endregion

    //#region ---- TEMPLATES FUNCTIONS

    //---- DOM Elements Query Selector
    $(q, asArray = false) {

        const els = this.shadowRoot ? this.shadowRoot.querySelectorAll(q) : document.querySelectorAll(q)

        if (els.length === 1) {
            return asArray ? els : els[0]
        }

        return els
    }

    generateDOMHtml(tmpl) {
        const docHTML = new DOMParser().parseFromString(tmpl, 'text/html')
        return docHTML.body.children;
    }

    getRootTmpl() {

        // const tmplHeader = this.isObjEmpty(this.options.search) ? this.getMapHeaderTmpl() : ''
        const tmplHeader = this.isObjEmpty(this.options.search) ? this.getMapHeaderTmpl() : ''

        return `
        <h1>Shadow Component Map</h1>
        <div id="${this.mapId}" class="map-wrapper">
            ${tmplHeader}
            <div class="map-container">
                <div class="map__inner"></div>
            </div>
            <div class="map-footer">
                <div class="btn-wrapper">
                    <button id="${this.mapId}-zoomIn">+</button>
                    <button id="${this.mapId}-zoomOut">-</button>
                    <button id="${this.mapId}-zoomReset">Reset</button>
                </div>

                <div class="site-stat-wrapper risk-wrapper right-border">
                    <div>Sites: <span id="${this.mapId}-visible-count">0</span>/<span id="${this.mapId}-total-count">0</span></div>
                    <div><span class="icon-sites-info"></span></div>
                </div>

                <div class="risk-wrapper right-border">
                    <div class="risk-wrapper-item">
                        <a href="javascript:void(0)" onclick="document.componentRegistry[${this._id}].clickOnScore(this)" data-risk='down'>
                        <div class="risk-sq down-badge"></div>Down <span class="risk-score-number" id="${this.mapId}-site-down">0</span>
                        </a>
                    </div>
                </div>

                <div class="risk-wrapper">
                    Risk:
                    <div class="risk-wrapper-item">
                        <a href="javascript:void(0)" class="" onclick="document.componentRegistry[${this._id}].clickOnScore(this)" data-risk='H'>
                        <div class="risk-sq h-badge"></div>High <span class="risk-score-number" id="${this.mapId}-risk-h">0</span>
                        </a>
                    </div>
                    <div class="risk-wrapper-item">
                        <a href="javascript:void(0)" class="" onclick="document.componentRegistry[${this._id}].clickOnScore(this)" data-risk='M'>
                            <div class="risk-sq m-badge"></div>Medium <span class="risk-score-number" id="${this.mapId}-risk-m">0</span>
                        </a>
                    </div>
                    <div class="risk-wrapper-item">
                        <a href="javascript:void(0)" class="" onclick="document.componentRegistry[${this._id}].clickOnScore(this)" data-risk='L'>
                            <div class="risk-sq l-badge"></div>Low <span class="risk-score-number" id="${this.mapId}-risk-l">0</span>
                        </a>
                    </div>
                    <div class="risk-wrapper-item">
                        <a href="javascript:void(0)" class="" onclick="document.componentRegistry[${this._id}].clickOnScore(this)" data-risk='N'>
                            <div class="risk-sq n-badge"></div>No Score <span class="risk-score-number" id="${this.mapId}-risk-n">0</span>
                        </a>
                    </div>
                </div>
            </div>
        `
    }

    getMapHeaderTmpl(data){
        const tmpl = `
            <div id="map-outer-widget" class="map-header">
                <div class="jq-wgt-title">${this.options.title}</div>
                <div class='js-search-box'></div>
            </div>
        `
        return tmpl
    }

    getSitePanelTmpl() {
        const currentType = this.state.currentPanel
        const tmpl = `
        <div class="info__inner" data-paneltype='${currentType}'>
            <div class="panel__header">
                <div class="site-breadcrumbs"></div>
                <div class="btn-close"></div>
            </div>
            <div class="panel__content"></div>
            <div class="panel__footer"></div>
        </div>
        `
        return tmpl
    }

    getClusterHeaderHtml() {
        return `
        <h3>Site Cluster</h3>
        <h5>Select site to view more details</h5>`
    }

    getClustersHtml(data){
        const arrTmpl = []
        const tmpl = (point) => {
            const item = point.options
            const cssClassBadge = `${item.srvRiskScore.toLowerCase()}-badge`
            return `
            <div class='info-flex-row'>
                <div class='site-name'>
                    <a href='javascript:void(0);' data-action='redirect' data-siteid='${item.srvId}'>${item.name}</a>
                    <div class="info-point-status">Up (12 Days)</div>
                </div>
                <div>
                    <div class='risk-badge ${cssClassBadge}'>${item.srvRisk}</div>
                </div>
                <div>
                    <div class='get-info-arrow' data-action='open' data-siteid='${item.srvId}'></div>
                </div>
            </div>
            `
        }

        if (Array.isArray(data)) {
            data.forEach((item) => {
                 arrTmpl.push(tmpl(item))
            })
        }

        return arrTmpl.join('')
    }

    getSiteHeaderHtml(item) {
        const tmpl = (item) => {
            const cssClassBadge = `${item.srvRiskScore.toLowerCase()}-badge`
            return `
            <div class='info-flex-row'>
                <div class='site-name'>
                <a href='javascript:void(0);' data-action='redirect' data-siteid='${item.srvId}'>${item.name}</a>
                </div>
                <div>
                    <div class='get-info-arrow' data-action='redirect' data-siteid='${item.srvId}'></div>
                </div>
            </div>
            `
        }

        return tmpl(item)

    }

    getSiteHtml(item) {

        const tmpl = (item) => {
            const _classBadge = `${item.srvRiskScore.toLowerCase()}-badge`
            return `
            <ul class="site-info-ul">
                <li>
                    <div class="site-info--label">Risk Score</div>
                    <div>
                        <div class="risk-badge ${_classBadge}">${item.srvRisk}</div>
                    </div>
                </li>
                <li><div class="site-info--label">Status</div><div>${this.converter.siteStatus(item.srvStatus)}</div></li>
                <li><div class="site-info--label">Last Downtime</div><div>3 days and 10 hours</div></li>
                <li><div class="site-info--label">Assets</div><div>92</div></li>
                <li><div class="site-info--label">Site ID</div><div>${item.srvId}</div></li>
                <li><div class="site-info--label">Version</div><div>7.6.10</div></li>
                <li><div class="site-info--label">License Status</div><div>Expiring on 02 Aug 2023</div></li>
                <li><div class="site-info--label">Location</div><div>${item.srvLocation}</div></li>
                <li><div class="site-info--label">Contact</div>
                    <div class="site-info--contact">
                        <div>${item.srvFirstName} ${item.srvLastName}</div>
                        <div>${item.srvPhone}</div>
                        <div><a href="mailto:${item.srvEmail}">${item.srvEmail}</a></div>
                    </div>
                </li>
            </ul>
            `
        }

        return  tmpl(item)
    }

    //#endregion

    //#region ---- HELPER FUNCTIONS

    generateNumRandom(maxLimit = 100) {
        const rand = Math.random() * maxLimit // say 99.81321410836433
        return Math.floor(rand) // 99
    }

    debounce(cb, delay = 250) {
        let debounceTimer
        return function() {
            const context = this
            const args = arguments
            clearTimeout(debounceTimer)
            debounceTimer = setTimeout(() => cb.apply(context, args), delay)
        }
    }

    callbackSearcher() {
        this.closeAllInfoPanel()
    }

    //---- Animate Risk in DOM
    animateStatisticScore() {
        const elRiskH           = this.$(`#${this.mapId}-risk-h`)
        const elRiskM           = this.$(`#${this.mapId}-risk-m`)
        const elRiskL           = this.$(`#${this.mapId}-risk-l`)
        const elRiskN           = this.$(`#${this.mapId}-risk-n`)
        const elDown            = this.$(`#${this.mapId}-site-down`)
        const elVisibleCount    = this.$(`#${this.mapId}-visible-count`)
        const elTotalCount      = this.$(`#${this.mapId}-total-count`)

        {
            let toH = 0
            let toM = 0
            let toL = 0
            let toN = 0

            const {H, M, L, N} = this.riskStatistic

            //---- Counter Down Sites
            elDown.innerHTML = this.statusStatistic.down

            //---- Visible Sites Statistic
            elVisibleCount.innerHTML = this.sitesTotalCounts - this.sitesLonLatStatistic
            elTotalCount.innerHTML   = this.sitesTotalCounts

            //---- Rsik Statistic
            if (H > 0) {
                this.countsH = setInterval(() => {
                    elRiskH.innerHTML = ++toH
                    if (toH === H) clearInterval(this.countsH)
                })
            }

            if (M > 0) {
                this.countsM = setInterval(() => {
                    elRiskM.innerHTML = ++toM
                    if (toM === M) clearInterval(this.countsM)
                })
            }

            if (L > 0) {
                this.countsL = setInterval(() => {
                    elRiskL.innerHTML = ++toL
                    if (toL === L) clearInterval(this.countsL)
                })
            }

            if (N > 0) {
                this.countsN = setInterval(() => {
                    elRiskN.innerHTML = ++toN
                    if (toN === N) clearInterval(this.countsN)
                })
            }


        }
    }

    //---- Set visible Amount cluster
    setVisibleClusterAmount() {
        if (this.isDebug) {
            console.log(`Method setVisibleClusterAmount()`)
        }
        const _clusterLabelWrapper = this.$('.highcharts-series-2.highcharts-mappoint-series .highcharts-label[opacity="0"]', true)

        _clusterLabelWrapper.forEach((element) => {
            element.setAttribute('opacity', 1)
        })
    }

    //---- Paint Cluster by Max Risk Status
    paintCluster(chart) {
        const points = chart.series[2].points
        // console.log("POINTS", points)
        points.forEach((point) => {
            if (!point.isCluster) {
                return;
            }

            const _hState = this.getMaxStatus(point.clusteredData)
            const _hColor = this.converter.siteRiskColor(_hState)

            if (point.marker) {
                point.marker.fillColor = _hColor
            }

            if (point.graphic) {
                point.graphic.fillColor = _hColor
                point.graphic.element.setAttribute('fill', _hColor)
            }
        })
    }

    //---- Close All Info Panels on Zooming or click on another Point
    closeAllInfoPanel() {
        const panelInfo = this.$(`#${this.mapId} .info__inner`)
        if(panelInfo?.classList?.contains('show')){
            panelInfo.classList.remove('show')
            // panelInfo.classList.remove("resize")
        }
    }

    clearStatistic() {
        Object.keys(this.riskStatistic).forEach(item => {
            this.riskStatistic[item] = 0
        })

        Object.keys(this.statusStatistic).forEach(item => {
            this.statusStatistic[item] = 0
        })


        this.sitesTotalCounts = 0
        this.sitesLonLatStatistic = 0

    }

    resetRiskFilter() {
        const allRisks = this.$(`#${this.mapId} a[data-risk]:not([data-risk='down'])`, true) //data-risk=down
        allRisks?.forEach((item) => {
            item.classList.remove('op-disabled')
            item.classList.remove('js-is-selected')
        })
        this.state.currentRiskMap = this.riskMap
    }

    toggleRiskLinks() {

        const currentRiskMap = [...this.state.currentRiskMap]
        const allLinks = document.querySelectorAll(`#${this.mapId} a[data-risk]:not([data-risk='down'])`)
        const isFullMap = currentRiskMap.length === this.riskMap.length

        for (const item of allLinks) {
            const dataItem = item.dataset.risk
            if (isFullMap) {
                item.classList.remove('js-is-selected');
            }
            if (currentRiskMap.includes(dataItem)) {
                item.classList.remove('op-disabled')
                // item.classList.add('js-is-selected');
            } else {
                item.classList.add('op-disabled')
                // item.classList.remove('js-is-selected');
            }

        }
    }

    //---- Get Max Risk Status in the Cluster
    getMaxStatus(items) {
        return items.reduce((acc, val) => {
            const valRisk = this.converter.probabilityRisk(val.options.srvRiskScore)
            const accRisk = this.converter.probabilityRisk(acc)
            acc = acc === '' || valRisk > accRisk ? val.options.srvRiskScore : acc
            return acc
        }, '')
    }

    clickOnPointHandler(point) {
        return new Promise((resolve, reject) => {
            resolve(point.clusteredData);
        })
    }

    //Function Proxy for clicked Risk Filter
    clickOnScore = new Proxy(this.renderByRiskSites, clickOnScoreHandler)

    clickOnSiteLink(el) {

        const a = el.target //---- Get DOM Element
        const { siteid, action} = a.dataset //---- Get Element Data

        //---- Check action
        if (action === 'open' || (action === 'redirect' && !this.SCApp)) {

        }
        else if(action === 'redirect' && this.SCApp) {
            this.redirectToSite(siteid)
        }

    }

    redirectToSite(siteId) {
        const entityTypeID = 21
        //---- Insert to storage new entity params
        const selectedNode = { entityID: siteId, entityTypeID };
        $.jStorage.set( "breadcrumbs_crossSite_header", selectedNode, true );
        //---- Change Hash for redirect
        helper.setHash( 'sites', 'dashboard' );
    }

    isNull(value) {
        if (value === null){
            return true;
        }
    }

    isObjEmpty (obj) {
        return Object.values(obj).length === 0 && obj.constructor === Object;
    }

    isArrayEqual(a, b) {
        return a.join() == b.join();
    }

    getState(prop) {
        if(!this.state.hasOwn(prop)) return null;

        return this.state[prop]
    }

    getDisabledChartOptions() {
        return {
            exporting: {
                enabled: false,
            },
            credits: {
                enabled: false,
            },
            title: {
                text: undefined,
            },
            subtitle: {
                text: undefined,
            },
        }
    }

    getChartTooltip() {
        const self = this
        return {
            useHTML: true,
            formatter() {
                //---- Cluster point
                if (this.point?.clusteredData) {
                    return self.renderTooltipCluster(this.point.clusteredData)
                }
                //---- Single site point
                else if (this.point?.lat) {
                    return self.renderTooltipSingle(this.point)
                }
                return false
            },
        }
    }

    getChartPlotOptions() {
        const self = this
        return {
            mappoint: {
                cluster: {
                    enabled: true,
                    allowOverlap: true,
                    overflow: true,
                    minimumClusterSize: 2,
                    animation: {
                        duration: 450,
                    },
                    layoutAlgorithm: {
                        type: 'grid',
                        gridSize: 65,
                    },
                    marker: {
                        fillColor: 'gray',
                        radius: 13,
                    },
                    zones: [
                        {
                            from: 1,
                            to: 4,
                            marker: {
                                radius: 13,
                            },
                        },
                        {
                            from: 5,
                            to: 9,
                            marker: {
                                radius: 15,
                            },
                        },
                        {
                            from: 10,
                            to: 15,
                            marker: {
                                radius: 17,
                            },
                        },
                        {
                            from: 16,
                            to: 50,
                            marker: {
                                radius: 19,
                            },
                        },
                        {
                            from: 51,
                            to: 1000,
                            marker: {
                                radius: 21,
                            },
                        },
                    ],
                    dataLabels: {
                        format: undefined,
                        formatter() {
                            //---- Cluster point
                            this.point.color = '#ffe100'
                            return this.point?.clusterPointsAmount
                        },
                        style: {
                            fontSize: '10px',
                            color: '#ffffff',
                            textOutline: 'transparent',
                            fontWeight: 'normal',
                        },
                        y: -1,
                        x: 0,
                    },
                    events: {
                        drillToCluster(target) {
                            console.log(`drillToCluster`, target)
                            const { point } = target;
                            const { isCluster, clusterPointsAmount, srvId, id, lon, lat } = point;

                            if ((isCluster && self.state.isMaxZoom)) {

                                //---- get elements from mappoint series and third cluster zone
                                const _arrAllElements = self.$(`g.highcharts-series-2 path.highcharts-cluster-zone-0`, true)

                                if (self.isDebug) {
                                    console.log(`All Elements:`, _arrAllElements)
                                }

                                //---- Object Point for the Last Cluster
                                const _LastCluster = {
                                    hiddenCluster: null,
                                    lastClusterOfMaxZoom: null
                                }

                                const arrElement = [..._arrAllElements].forEach((el) => {

                                    //---- if element point id equal for clicked point id and element visibility = hidden
                                    if (el.point?.id === id && el.hasAttribute("visibility")) {
                                        _LastCluster.hiddenCluster = el
                                    }

                                    //---- comparison of indexes cluster data of a hidden cluster object
                                    const _isSameCluster = el.point.clusteredData.find((item, index) => {
                                        return (_LastCluster.hiddenCluster?.point.clusteredData[index]?.dataIndex === item.dataIndex)
                                    })

                                    //---- if there is a match between a hidden and a visible cluster, define this point as the last non-discoverable cluster
                                    if (_isSameCluster && !el.hasAttribute("visibility") ) {
                                        _LastCluster.lastClusterOfMaxZoom = el
                                    }
                                })

                                if (self.isDebug) {
                                    console.log(`_LastCluster Cluster:`, _LastCluster)
                                    console.log(`Hidden Cluster:`, _LastCluster.hiddenCluster)
                                    console.log(`lastPointOfMaxZoom Elements:`, _LastCluster.lastClusterOfMaxZoom)
                                }

                                //---- if it a last non-discoverable cluster
                                if (_LastCluster.lastClusterOfMaxZoom) {
                                    self.clickOnPointHandler(_LastCluster.lastClusterOfMaxZoom.point).then((data) => {
                                        if (self.isDebug) {
                                            console.log(`clickOnPointHandler data:`, data)
                                        }

                                        //TODO BUILD Sites Panel
                                        if(Highcharts.isArray(data)) {
                                            //---- Render Cluster Panel
                                            self.renderSitePanel(data, self.panelType.CLUSTER)
                                        }
                                    })
                                }

                            }
                            else if (isCluster) {

                                if (self.isDebug) {
                                    console.log(`IsCluster: ${isCluster}; clusterPointsAmount: ${clusterPointsAmount}`, target)
                                }
                                return
                            }
                        },
                    },
                },
            },
            series: {
                states: {
                    inactive: {
                        opacity: 1,
                    },
                },
                point: {
                    events: {
                        async click(target) {
                            // createPointLabel(this)
                            const { point } = target;

                            if (self.isDebug) {
                                console.log(`Click target ->`, target)
                                console.log(`Click Zoom:${self.chart.mapView.zoom} -> MaxZoom ${self.chart.mapView.options.maxZoom}`)
                            }

                            const { isCluster, clusterPointsAmount, srvId, id, lon, lat } = point;

                            if ((isCluster && self.state.isMaxZoom)) {

                                //---- get elements from mappoint series and third cluster zone
                                const _arrAllElements = self.$(`g.highcharts-series-2 path.highcharts-cluster-zone-0`, true)

                                if (self.isDebug) {
                                    console.log(`All Elements:`, _arrAllElements)
                                }

                                //---- Object Point for the Last Cluster
                                const _LastCluster = {
                                    hiddenCluster: null,
                                    lastClusterOfMaxZoom: null
                                }

                                const arrElement = [..._arrAllElements].forEach((el) => {

                                    //---- if element point id equal for clicked point id and element visibility = hidden
                                    if (el.point?.id === id && el.hasAttribute("visibility")) {
                                        _LastCluster.hiddenCluster = el
                                    }

                                    //---- comparison of indexes cluster data of a hidden cluster object
                                    const _isSameCluster = el.point.clusteredData.find((item, index) => {
                                        return (_LastCluster.hiddenCluster?.point.clusteredData[index]?.dataIndex === item.dataIndex)
                                    })

                                    //---- if there is a match between a hidden and a visible cluster, define this point as the last non-discoverable cluster
                                    if (_isSameCluster && !el.hasAttribute("visibility") ) {
                                        _LastCluster.lastClusterOfMaxZoom = el
                                    }
                                })

                                if (self.isDebug) {
                                    console.log(`_LastCluster Cluster:`, _LastCluster)
                                    console.log(`Hidden Cluster:`, _LastCluster.hiddenCluster)
                                    console.log(`lastPointOfMaxZoom Elements:`, _LastCluster.lastClusterOfMaxZoom)
                                }

                                //---- if it a last non-discoverable cluster
                                if (_LastCluster.lastClusterOfMaxZoom) {
                                    self.clickOnPointHandler(_LastCluster.lastClusterOfMaxZoom.point).then((data) => {
                                        if (self.isDebug) {
                                            console.log(`clickOnPointHandler data:`, data)
                                        }

                                        //TODO BUILD Sites Panel
                                        if(Highcharts.isArray(data)) {
                                            //---- Render Cluster Panel
                                            self.renderSitePanel(data, self.panelType.CLUSTER)
                                        }
                                    })
                                }
                                return
                            }

                            else if (isCluster) {

                                if (self.isDebug) {
                                    console.log(`IsCluster: ${isCluster}; clusterPointsAmount: ${clusterPointsAmount}`, target)
                                }
                                return
                            }
                            // Single Site
                            else if (srvId) {
                                if (self.isDebug) {
                                    console.log(`Single Site: ${srvId}`, target)
                                }
                                // self.chart.get(point.countryCode).zoomTo();
                                // point.zoomTo();
                                // self.chart.mapView.zoomBy([lon, lat])
                                self.renderSitePanel(point, self.panelType.SITE)
                                // self.chart.redraw();
                                return
                            }
                            else {
                                // console.log(`Not Point:`, target)
                            }
                        },
                    },
                },
            },
        }
    }

    isElementVisible(element) {
        return element.offsetWidth || element.offsetHeight || element.getClientRects().length ? true : false;
    }
    //#endregion

}

function RiskParamsConverter() {
    return {
        siteRiskColor(data) {
            const Colors = {
                H: '#D60B13',
                M: '#FFC527',
                L: '#279D2B',
                N: '#B0B0B0',
            }
            return Colors[data] ? Colors[data] : ''
        },
        probabilityRisk(data) {
            const Risk = {
                H: 4,
                M: 3,
                L: 2,
                N: 1,
            }
            return Risk[data] ? Risk[data] : ''
        },
        pointMarker(_type) {
            switch (_type) {
                case 'H':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-red.png)',
                    }
                case 'M':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-yellow.png)',
                    }
                case 'L':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-green.png)',
                    }
                case 'Down': {
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-black.png)',
                    }
                }
                default:
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-gray.png)',
                    }
            }
        },
        riskSeverity(sev) {
            const riskSeverity = {
                L: 'Low',
                M: 'Medium',
                H: 'High',
                N: 'No Score'
            }
            return riskSeverity[sev] ? riskSeverity[sev] : ''
        },
        siteStatus(status) {
            const siteStatus = {
                up: 'Up',
                down: 'Down',
                offline: 'Offline',
                manual: 'Manual',
            }
            return siteStatus[status] ? siteStatus[status] : ''
        },
    }
}


//---- Proxy Handler for Function
const clickOnScoreHandler = {
    apply(target, thisArg, argumentsList) {

        // console.log(`Calling function ${thisArg._id}`, thisArg, argumentsList);

        const a = argumentsList[0]   //---- Get DOM Element
        let _data = a.dataset.risk //---- Get Element Data

        const downLink = document.querySelector(`#${thisArg.mapId} a[data-risk='down']`)
        const isDownSelected = downLink.classList.contains('js-is-selected')

        thisArg.closeAllInfoPanel()

        //---- Clicked Down Link
        if(_data === thisArg.siteStatus.down) {
            thisArg.chart.mapView.zoomBy()

            thisArg.resetRiskFilter()

            thisArg.renderByStatus(_data)

            if (isDownSelected) {
                a.classList.remove('js-is-selected');
            } else {
                a.classList.add('js-is-selected');
            }

            return
        }

        if(isDownSelected) {
           return;
        }

        //---- Get Current status of the link
        const isCurrSelectedLink = a.classList.contains('js-is-selected')

        if(isCurrSelectedLink) {
            a.classList.remove('js-is-selected');
        } else {
            a.classList.add('js-is-selected');
        }


        const data = {
            key: _data,
            selected: !isCurrSelectedLink
        }

        return target.apply(thisArg, [data]);
    }
}

const clickOnSiteLinkHandler = {
    apply(target, thisArg, argumentsList) {

        // console.log(`Calling function ${thisArg._id}`, thisArg, argumentsList);

        const a = argumentsList[0]  //---- Get DOM Element
        const { siteid, action} = a.dataset //---- Get Element Data


        //---- Check action
        if(action === 'open') {

        }


        return target.apply(thisArg, [data]);
    }
}

const clickOnOpenLinkHandler = {
    apply(target, thisArg, argumentsList) {

        // console.log(`Calling function ${thisArg._id}`, thisArg, argumentsList);

        const a = argumentsList[0]  //---- Get DOM Element
        const data = a.dataset.risk //---- Get Element Data

        //---- Change Style Element
        if (a.classList.contains('op-disabled')) {
            a.classList.remove('op-disabled')
        } else {
            a.classList.add('op-disabled')
        }

        return target.apply(thisArg, [data]);
    }
}

// export const map = new Map()
