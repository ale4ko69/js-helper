import { customEvents, createCustomEvent } from './Util.js'
/** search module */

export default class Searcher {

    constructor(map, props) {
        this.map            = map
        this.mapId          = map.mapId
        this.shadowRoot     = props.shadowRoot

        if (this.shadowRoot){
            this.searchBoxDOM   = props.searchBoxDOM ?? this.shadowRoot.querySelector(`#${this.mapId} .js-search-box`)
        }
        else {
            this.searchBoxDOM   = props.searchBoxDOM ?? document.querySelector(`#${this.mapId} .js-search-box`)
        }

        this.SearcherHtml   = this.generateDOMHtml(this.getSearchBoxHtml())[0]

        this.searchBoxDOM.innerHTML = '';
        // this.searchBoxDOM.insertAdjacentHTML('beforeend', this.SearcherHtml)

        this.searchBoxDOM.appendChild(this.SearcherHtml)

        this._inpSearch     = this.shadowRoot.querySelector(`#${this.mapId} .js-search-box #${this.mapId}-search-input`),
        this._btnReload     = this.shadowRoot.querySelector(`#${this.mapId} .js-search-box #${this.mapId}-reload-map-btn`),
        this._btnSearch     = this.shadowRoot.querySelector(`#${this.mapId} .js-search-box #${this.mapId}-search-btn`),
        this._suggestions   = this.shadowRoot.querySelector(`#${this.mapId} .js-search-box #${this.mapId}-suggestions ul`);

        this.bindEvents()
    }

    search(str) {

        const re = new RegExp(`.?(${str}).?`, 'i')
        const _sites = [...this.map.state.currentPointers]

        if (str.length === 0) {
            return _sites
        }

        //Find Sites by text in
        const searchResult = _sites.filter((srv) => {
            if (re.test(srv.name)) return srv
        })

        return searchResult;
    }

    searchHandler(e) {
        const inputVal = e.target.value;
        if(inputVal.length > 0){
            const results =  this.search(inputVal);
            this.showSuggestions(results, inputVal);
        }
    }

    showSuggestions(results, inputVal) {

        this._suggestions.innerHTML = '';

        if (results.length > 0) {
            for (const item of results) {
                const re = new RegExp(`(${inputVal})`, 'i')
                const match = item.name.match(re);
                const itemName = item.name.replace(match[0], `<strong>${match[0]}</strong>`);
                this._suggestions.innerHTML += `<li data-srv-id='${item.srvId}' title='${item.name}; ${item.srvLocation}'>${itemName}</li>`;
            }
            this._suggestions.classList.add('has-suggestions');
            return;
        }

        results = [];
        this._suggestions.innerHTML = '';
        this._suggestions.classList.remove('has-suggestions');
    }

    useSuggestion(e) {

        if (e.target.nodeName !== 'LI')
            return

        const srvId = e.target.dataset.srvId

        this._inpSearch.value = e.target.innerText;
        this._inpSearch.focus();

        this._suggestions.dispatchEvent(createCustomEvent(customEvents.selectedOption, {srvId}));
    }

    hideSuggestion() {

        if(!this._suggestions.classList.contains('has-suggestions')) {
            return;
        }
        this._inpSearch.value = ''
        this._suggestions.innerHTML = '';
        this._suggestions.classList.remove('has-suggestions');
    }

    showSearchBox() {
        if (!this._inpSearch.classList.contains('show')){
            this._inpSearch.classList.add('show')
            setTimeout(() => {
                this._inpSearch.focus()
            }, 750)
        }
    }

    hideSearchBox() {
        if (this._inpSearch.classList.contains('show')){
            this._inpSearch.value = ''
            this._inpSearch.classList.remove('show')
        }
    }

    bindEvents(){
        const _self = this

        this._btnReload.addEventListener('click', () => {
            this.map.reload()
        })

        this._btnSearch.addEventListener('click', () => {
            this.showSearchBox()
        })

        this._suggestions.addEventListener('click', (e) => _self.useSuggestion(e));

        // this._offKeyUp = this.on(this._inpSearch, 'keyup', )

        this._inpSearch.addEventListener('keyup', (ev) => {
            _self.searchHandler(ev)
            ev.stopPropagation()
        })

            // return _self.debounce((ev) =>{
            //         _self.searchHandler(ev)
            //         ev.stopPropagation()
            // }, 450)


        window.addEventListener('click', (ev) => {
            console.log(ev.target.contains(_self._suggestions), ev.target, _self._suggestions)
            if (ev.target.contains(_self._suggestions) && ev.target !== _self._suggestions){
                _self._inpSearch.dispatchEvent(createCustomEvent(customEvents.closeBox));
            }
        });

        this._inpSearch.addEventListener(customEvents.closeBox, (ev) => this.onHideSearchBox(ev))
        this._suggestions.addEventListener(customEvents.selectedOption, (ev) => this.onSelectOption(ev))
    }

    onHideSearchBox(ev) {
        console.log(`Dispatch Event closeBox`, ev)
        this.hideSuggestion()
        this.hideSearchBox()
    }

    onSelectOption(ev) {
        console.log(`Dispatch Event selectedOption`, ev)
        const data = {
            srvId: ev.detail.srvId
        }
        this.hideSearchBox()
        this.hideSuggestion()
        this.map.renderSitePanel(data, this.map.panelType.SITE)
        this.map.chart.mapView.zoomBy()
    }

    debounce(cb, delay = 250) {
        let debounceTimer
        return function() {
            const context = this
            const args = arguments
            clearTimeout(debounceTimer)
            debounceTimer = setTimeout(() => {
                cb.apply(context, args), delay
            })

        }
    }

    getSearchBoxHtml() {
        const html = `
            <div class="header-search-wrapper">
                <div class="input-wrap">
                    <button id="${this.mapId}-search-btn" class="icon-btn search-btn" title="Search Site"></button>
                    <input type="text" id="${this.mapId}-search-input" placeholder="Search site" class="search-input">
                </div>
                <button id="${this.mapId}-reload-map-btn" class="icon-btn reload-btn" title="Reload Site Map"></button>
                <div class="search-container">
                    <div id="${this.mapId}-suggestions" class="suggestions">
                        <ul></ul>
                    </div>
                </div>
            </div>
        `

        return html
    }

    generateDOMHtml(tmpl) {
        const docHTML = new DOMParser().parseFromString(tmpl, 'text/html')
        return docHTML.body.children;
    }

    on(el, evt, cb) {
        el.addEventListener(evt, cb);
        return () => {
          el.removeEventListener(evt, cb);
        }
      }
}
