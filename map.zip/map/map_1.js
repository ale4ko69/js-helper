export function Map(oHighcharts, oRootDom, oRootFooter) {
    let isDebug = true
    const urlEpMap = '/assets/map/@highcharts/map-collection'
    const urlDefaultMap = '/custom/world-highres2.topo.json' //world-continents.topo.json; world.topo.json; world-highres2.topo.json
    const Highcharts = oHighcharts
    const root = document.querySelector(oRootDom)
    let mapContainer
    let mapFooter
    let worldMap
    let dataPointers
    let dataCountries
    let chart
    let geojson
    let _infoPanel
    let _btnClose
    let _btnZoomReset
    let _btnZoomIn
    let _btnZoomOut
    let _inpSearch
    let currentMap = []
    let mapId
    let headerId
    let footerId
    let hRisk = 0
    let mRisk = 0
    let lRisk = 0
    let noRisk = 0
    let countsH
    let countsM
    let countsL
    let countsN
    const arrRisk = ['H', 'M', 'L', 'N']
    const panelType = {
        'CLUSTER': 'Cluster',
        'SITE': 'Site',
        'CLUSTER_SITE': 'Cluster_Site'
    }
    let countTimer
    let isMaxZoom = false
    let clickedPoint = null
    let isLastCluster = false
    let lastClusterID = ''

    Highcharts.wrap(Highcharts.Chart.prototype, 'showResetZoom', (proceed) => {})

    async function Init() {
        try {
            //Render ID for Map Widget
            const rndID = generateRiskRandom(1000)
            mapId = `map-${rndID}`
            headerId = `header-${rndID}`
            footerId = `footer-${rndID}`

            root.innerHTML = getRootHtml()

            mapContainer = root.querySelector(`#${mapId} .map__inner`)
            mapFooter = root.querySelector(`#${footerId}`)
            _infoPanel = document.querySelector(`#${mapId} .info__inner`)
            _btnClose = document.querySelector(`#${mapId} .btn-close`)
            _btnZoomReset = document.querySelector(`#${mapId}-zoomReset`)
            _btnZoomIn = document.querySelector(`#${mapId}-zoomIn`)
            _btnZoomOut = document.querySelector(`#${mapId}-zoomOut`)
            _inpSearch = document.querySelector(`#${mapId}-search-input`)

            // Get World Map
            await getWorldMap()

            // Get Countries
            const data = await getData()

            // data.forEach((p) => {
            //     p.push(p[0])
            // })

            dataCountries = data

            // TODO Select data from server
            // dataPointers = prepareData(getFullSites());
            const _dataPointers = await import('/assets/map/full-sites-data.js')
            dataPointers = _dataPointers.default

            //---- Count Risk Score
            dataPointers.forEach((item) => {
                switch (item.srvRiskScore) {
                    case 'H':
                        hRisk++
                        break
                    case 'M':
                        mRisk++
                        break
                    case 'L':
                        lRisk++
                        break
                    case 'N':
                        item.srvRisk = 0
                        noRisk++
                        break
                }
            })

            chart = await renderByRiskSites()

            //---- Bind Buttons Events
            bindWidgetEvents()

            //---- Create Risk Score Legends
            animateRiskScore()

        } catch (err) {
            console.log(err)
        }
    }

    //Get World Map
    async function getWorldMap(epMap) {
        const url = epMap ?? urlDefaultMap
        const _topology = await fetch(`${urlEpMap}${url}`).then((response) => response.json())

        worldMap = _topology
        geojson = Highcharts.topo2geo(worldMap)

        if (isDebug) {
            console.log('map.js - getTopology -> topology', worldMap)
            // console.log('map.js - getTopology -> eu', eu)
            // console.log('map.js - getTopology -> eu _data', _data)
            console.log('map.js - getTopology -> geojson', geojson)
        }

        return worldMap
    }

    //Get Countries Code ???
    async function getData(url) {
        //TODO GET FROM SERVER
        // Prepare demo data. The data is joined to map using value of 'hc-key'
        // property by default. See API docs for 'joinBy' for more info on linking
        // data and map.
        const _data = [
            ['fo', 0],
            // ["um", 1],
            ['us', 2],
            ['jp', 3],
            ['sc', 4],
            ['in', 5],
            ['fr', 6],
            // ["fm", 7],
            ['cn', 8],
            ['pt', 9],
            ['sw', 10],
            ['sh', 11],
            ['br', 12],
            // ["ki", 13],
            ['ph', 14],
            ['mx', 15],
            ['es', 16],
            ['bu', 17],
            ['mv', 18],
            ['sp', 19],
            ['gb', 20],
            ['gr', 21],
            // ["as", 22],
            ['dk', 23],
            ['gl', 24],
            // ["gu", 25],
            ['mp', 26],
            ['pr', 27],
            ['vi', 28],
            ['ca', 29],
            ['st', 30],
            ['cv', 31],
            ['dm', 32],
            ['nl', 33],
            ['jm', 34],
            // ["ws", 35],
            ['om', 36],
            ['vc', 37],
            ['tr', 38],
            ['bd', 39],
            ['lc', 40],
            // ["nr", 41],
            ['no', 42],
            ['kn', 43],
            ['bh', 44],
            // ["to", 45],
            ['fi', 46],
            ['id', 47],
            ['mu', 48],
            ['se', 49],
            ['tt', 50],
            ['my', 51],
            ['pa', 52],
            // ["pw", 53],
            // ["tv", 54],
            // ["mh", 55],
            ['cl', 56],
            ['th', 57],
            ['gd', 58],
            ['ee', 59],
            ['ag', 60],
            ['tw', 61],
            ['bb', 62],
            ['it', 63],
            ['mt', 64],
            // ["vu", 65],
            ['sg', 66],
            ['cy', 67],
            ['lk', 68],
            ['km', 69],
            // ["fj", 70],
            ['ru', 71],
            ['va', 72],
            ['sm', 73],
            ['kz', 74],
            ['az', 75],
            ['tj', 76],
            ['ls', 77],
            ['uz', 78],
            ['ma', 79],
            ['co', 80],
            ['tl', 81],
            ['tz', 82],
            ['ar', 83],
            ['sa', 84],
            ['pk', 85],
            ['ye', 86],
            ['ae', 87],
            ['ke', 88],
            ['pe', 89],
            ['do', 90],
            ['ht', 91],
            ['pg', 92],
            ['ao', 93],
            ['kh', 94],
            ['vn', 95],
            ['mz', 96],
            ['cr', 97],
            ['bj', 98],
            ['ng', 99],
            ['ir', 100],
            ['sv', 101],
            ['sl', 102],
            ['gw', 103],
            ['hr', 104],
            ['bz', 105],
            ['za', 106],
            ['cf', 107],
            ['sd', 108],
            ['cd', 109],
            ['kw', 110],
            ['de', 111],
            ['be', 112],
            ['ie', 113],
            ['kp', 114],
            ['kr', 115],
            ['gy', 116],
            ['hn', 117],
            ['mm', 118],
            ['ga', 119],
            ['gq', 120],
            ['ni', 121],
            ['lv', 122],
            ['ug', 123],
            ['mw', 124],
            ['am', 125],
            ['sx', 126],
            ['tm', 127],
            ['zm', 128],
            ['nc', 129],
            ['mr', 130],
            ['dz', 131],
            ['lt', 132],
            ['et', 133],
            ['er', 134],
            ['gh', 135],
            ['si', 136],
            ['gt', 137],
            ['ba', 138],
            ['jo', 139],
            ['sy', 140],
            ['mc', 141],
            ['al', 142],
            ['uy', 143],
            ['cnm', 144],
            ['mn', 145],
            ['rw', 146],
            ['so', 147],
            ['bo', 148],
            ['cm', 149],
            ['cg', 150],
            ['eh', 151],
            ['rs', 152],
            ['me', 153],
            ['tg', 154],
            ['la', 155],
            ['af', 156],
            ['ua', 157],
            ['sk', 158],
            ['jk', 159],
            ['bg', 160],
            ['qa', 161],
            ['li', 162],
            ['at', 163],
            ['sz', 164],
            ['hu', 165],
            ['ro', 166],
            ['ne', 167],
            ['lu', 168],
            ['ad', 169],
            ['ci', 170],
            ['lr', 171],
            ['bn', 172],
            ['iq', 173],
            ['ge', 174],
            ['gm', 175],
            ['ch', 176],
            ['td', 177],
            ['kv', 178],
            ['lb', 179],
            ['dj', 180],
            ['bi', 181],
            ['sr', 182],
            ['il', 183],
            ['ml', 184],
            ['sn', 185],
            ['gn', 186],
            ['zw', 187],
            ['pl', 188],
            ['mk', 189],
            ['py', 190],
            ['by', 191],
            ['cz', 192],
            ['bf', 193],
            ['na', 194],
            ['ly', 195],
            ['tn', 196],
            ['bt', 197],
            ['md', 198],
            ['ss', 199],
            ['bw', 200],
            ['bs', 201],
            ['nz', 202],
            ['cu', 203],
            ['ec', 204],
            ['au', 205],
            ['ve', 206],
            ['sb', 207],
            ['mg', 208],
            ['is', 209],
            ['eg', 210],
            ['kg', 211],
            ['np', 212],
        ]
        return _data
    }

    const getCountryFeature = (a2) => {
        const country = geojson.features.find((f) => {
            if (f.properties['hc-key'] === a2) return f
        })
        return country
    }

    async function render(sites) {
        const chart = Highcharts.mapChart(mapContainer, {
            chart: {
                // map: worldMap,
                backgroundColor: 'none',
                margin: [0, 0, 0, 0],
                // zoomType: 'xy',
                // panning: {
                //     enabled: true,
                //     type: 'xy'
                // },
                events: {
                    load(ev) {

                        console.log("Event load", ev)

                        const mapView = this.mapView;
                        const points = this.series[2].points;
                        const maxLat = Math.max(...points.map(p => p.lat));
                        const maxLon = Math.max(...points.map(p => p.lon));
                        const minLat = Math.min(...points.map(p => p.lat));
                        const minLon = Math.min(...points.map(p => p.lon));

						 const maxLatLon = mapView.lonLatToProjectedUnits({
						 	lat: maxLat,
							lon: maxLon
						 });

						 const minLatLon = mapView.lonLatToProjectedUnits({
						 	lat: minLat,
							lon: minLon
						 });

						 const bounds = {
						 	x1: minLatLon.x,
							y1: minLatLon.y,
							x2: maxLatLon.x,
							y2: maxLatLon.y
						 };

						 mapView.fitToBounds(bounds, '5%');
                    },
                    render(ev) {
                        const chart = this
                        if (isDebug) {
                            console.log("Event render", ev)
                        }

                        setTimeout(setVisibleClusterAmount, 150)

                        console.log(`Render Zoom:${chart.mapView.zoom} -> MaxZoom ${chart.mapView.options.maxZoom}`)

                        isMaxZoom = chart.mapView.zoom === chart.mapView.options.maxZoom

                        if(clickedPoint?.point?.destroyed) {
                            isLastCluster = true
                        }

                        clickedPoint = null
                    },
                    redraw(ev) {
                        const chart = this
                        if (isDebug) {
                            console.log("Event redraw", ev)
                        }
                        paintCluster(chart)
                    },
                },
            },
            exporting: {
                enabled: false,
            },
            credits: {
                enabled: false,
            },
            title: {
                text: undefined,
            },
            subtitle: {
                text: undefined,
            },

            tooltip: {
                useHTML: true,
                formatter() {
                    //Cluster point
                    if (this.point?.clusteredData) {
                        return createTooltipCluster(this.point.clusteredData)
                    }
                    //Single site point
                    else if (this.point?.lat) {
                        return createTooltipSingle(this.point)
                    }
                    return false
                },
            },

            mapView: {
                // fitToGeometry: countryGeometry(), //1.
                // padding: 15,                      //2.
                // center: [25, 25],                 //3.
                // zoom: 3,                          //4.
                maxZoom: 10,
            },

            mapNavigation: {
                enabled: true,
                // enableDoubleClickZoomTo: true,
                enableButtons: false,
                enableMouseWheelZoom: true,
            },

            legend: {
                enabled: false,
                symbolRadius: 0,
                symbolHeight: 14,
            },

            plotOptions: {
                mappoint: {
                    cluster: {
                        enabled: true,
                        allowOverlap: true,
                        overflow: true,
                        minimumClusterSize: 2,
                        animation: {
                            duration: 450,
                        },
                        layoutAlgorithm: {
                            // type: 'optimalizedKmeans'
                            type: 'grid',
                            gridSize: 45,
                        },
                        marker: {
                            fillColor: 'gray',
                            radius: 13,
                        },
                        zones: [
                            {
                                from: 1,
                                to: 4,
                                marker: {
                                    radius: 13,
                                },
                            },
                            {
                                from: 5,
                                to: 9,
                                marker: {
                                    radius: 15,
                                },
                            },
                            {
                                from: 10,
                                to: 15,
                                marker: {
                                    radius: 17,
                                },
                            },
                            {
                                from: 16,
                                to: 50,
                                marker: {
                                    radius: 19,
                                },
                            },
                            {
                                from: 51,
                                to: 1000,
                                marker: {
                                    radius: 21,
                                },
                            },
                        ],
                        dataLabels: {
                            format: undefined,
                            formatter() {
                                // Cluster point
                                this.point.color = '#ffe100'
                                return this.point?.clusterPointsAmount
                            },
                            style: {
                                fontSize: '10px',
                                color: '#ffffff',
                                textOutline: 'transparent',
                                fontWeight: 'normal',
                            },
                            y: -1,
                            x: 0,
                        },
                        events: {
                            drillToCluster(ev) {
                                const cluster = this
                                const ch = chart
                                // console.log('drillToCluster -> Chart', ch)
                                // console.log('drillToCluster -> Cluster', cluster)
                                // console.log('drillToCluster -> Event Point', ev)
                                // const cords = chart.mapView.pixelsToLonLat({ x: chart.plotLeft + 45, y: chart.plotTop + 20 });
                                // chart.series[1].addPoint({ ...cords });
                            },
                        },
                    },
                },
                series: {
                    states: {
                        inactive: {
                            opacity: 1,
                        },
                    },
                    point: {
                        events: {
                            async click(target) {
                                // createPointLabel(this)
                                const { point } = target;
                                const { isCluster, clusterPointsAmount, srvId, id } = point;
                                console.log(`Click target ->`, target)
                                console.log(`Click Zoom:${chart.mapView.zoom} -> MaxZoom ${chart.mapView.options.maxZoom}`)

                                // Cluster
                                if ((isCluster && isMaxZoom)) {
                                    let lastPointOfMaxZoom;
                                    // get elements from mappoint series and first cluster zone
                                    const arrAllElements = document.querySelectorAll(`g.highcharts-series-2 path.highcharts-cluster-zone-0`)

                                    if (isDebug) {
                                        console.log(`All Elements:`, arrAllElements)
                                    }

                                    const _LastCluster = {
                                        hiddenCluster: null,
                                        lastClusterOfMaxZoom: null
                                    }

                                    const arrElement = [...arrAllElements].forEach((el) => {

                                        if (el.point?.id === id && el.hasAttribute("visibility")) {
                                            _LastCluster.hiddenCluster = el
                                        }

                                        const isSameCluster = el.point.clusteredData.find((item, index) => {
                                            return (_LastCluster.hiddenCluster?.point.clusteredData[index]?.dataIndex === item.dataIndex)
                                        })

                                        if (isSameCluster && !el.hasAttribute("visibility") ) {
                                            _LastCluster.lastClusterOfMaxZoom = el
                                        }
                                    })

                                    if (isDebug) {
                                        console.log(`_LastCluster Cluster:`, _LastCluster)
                                        console.log(`Hidden Cluster:`, _LastCluster.hiddenCluster)
                                        console.log(`lastPointOfMaxZoom Elements:`, _LastCluster.lastClusterOfMaxZoom)
                                    }

                                    if (_LastCluster.lastClusterOfMaxZoom) {
                                        clickOnPointHandler(_LastCluster.lastClusterOfMaxZoom.point).then((data) => {
                                            if (isDebug) {
                                                console.log(`clickOnPointHandler data:`, data)
                                            }

                                            //TODO BUILD Sites Panel
                                            if(Highcharts.isArray(data)) {
                                                buildSitePanel(data, panelType.CLUSTER)
                                            }
                                        })
                                    }

                                }
                                else if (isCluster) {

                                    if (isDebug) {
                                        console.log(`IsCluster: ${isCluster}; clusterPointsAmount: ${clusterPointsAmount}`, target)
                                    }

                                    clickedPoint = target;
                                    isLastCluster = false;
                                    lastClusterID = '';
                                    return
                                }
                                // Single Site
                                else if (srvId) {
                                    console.log(`Single Site: ${srvId}`, target)
                                    buildSitePanel(point, panelType.SITE)
                                } else {
                                    console.log(`Not Point:`, target)
                                }
                            },
                        },
                    },
                },
            },

            series: [
                {
                    id: 'world-map',
                    allAreas: false,
                    type: 'map',
                    name: 'World Map',
                    joinBy: ['hc-key'],
                    color: 'rgba(244, 244, 242, 0.85)',
                    nullColor: 'rgba(244, 244, 242, 0.2)',
                    borderColor: 'rgba(0, 0, 0, 0)',
                    enableMouseTracking: false, //disable tooltips for specific series
                    events: {
                        click(e) {
                            e.point.zoomTo()
                            // chart.render()
                        },
                    },
                    dataLabels: {
                        enabled: true,
                        inside: true,
                        allowOverlap: false,
                        format: '{point.name}',
                        style: {
                            color: '#6e6e6e',
                            textOutline: 'transparent',
                            fontWeight: 'normal',
                        },
                    },
                    data: dataCountries,
                    // affectsMapView: false,
                    mapData: worldMap,
                },
                {
                    name: 'Separators',
                    type: 'mapline',
                    nullColor: '#279D2B',
                    showInLegend: false,
                    enableMouseTracking: true,
                    accessibility: {
                        enabled: false,
                    },
                },
                {
                    id: 'map-point',
                    type: 'mappoint',
                    colorKey: 'clusterPointsAmount',
                    name: 'Sites',
                    joinBy: null,
                    enableMouseTracking: true,
                    dataLabels: {
                        enabled: true,
                        format: undefined,
                        nullFormat: false,
                        formatter() {
                            // Single point not show Label
                            return this.point?.clusterPointsAmount
                        },
                    },
                    data: sites,
                },
            ],
        })

        chart.redraw()

        if (isDebug) {
            console.log('map.js - render -> InstWidget: ', chart)
            console.log('map.js - render -> dataPointers: ', dataPointers)
        }

        return chart
    }

    //---- Once

    //---- Buttons
    function bindWidgetEvents() {

        _btnClose.addEventListener('click', () => {
            closeInfoPanel()
        })

        _btnZoomReset.addEventListener('click', () => {
            closeInfoPanel()
            chart.mapView.zoomBy()
        })

        _btnZoomIn.addEventListener('click', () => {
            closeInfoPanel()
            chart.mapView.zoomBy(0.9)
        })

        _btnZoomOut.addEventListener('click', () => {
            closeInfoPanel()
            chart.mapView.zoomBy(-1.1)
        })

        // _btnZoomBelgium?.addEventListener('click', function () {
        //     chart.get('be').zoomTo();
        // });

        _inpSearch.addEventListener('keyup', function (ev) {
            const value = ev.currentTarget.value
            if (value.length === 0 || value.length >= 3) {
                closeInfoPanel()
                searchSites(value)
            }
        })
    }

    //---- Create Point LABEL ???
    function createPointLabel(self) {
        // Show click only map point
        if (self.series?.userOptions.id === 'world-map' || !self.name) return

        const _text = `<b>Clicked point</b><br>Series: ${self.series.name}
        <br>Point: ${self.srvName} (lat: ${self.lat} lon:${self.lon})`

        const { chart } = self.series

        // console.log(chart)

        const { x: chX, y: chY, width: chWidth, height: chHeight } = chart.plotBox

        if (chart.pointLabel) {
            chart.pointLabel?.destroy()
            chart.pointLabel = undefined
        }

        const { renderer } = chart

        const groupLabel = renderer.g().add().toFront()

        renderer
            .label(_text, chWidth - 285, chY)
            .css({
                width: '380px',
            })
            .attr({
                fill: '#FFFFEF',
                stroke: 'gray',
                'stroke-width': 1,
                zIndex: 4,
            })
            .add(groupLabel)
            .toFront()

        const { width: grWidth, x: grX, y: grY } = groupLabel.getBBox()

        const text = renderer
            .text('x', grX + grWidth - 14, grY + 12)
            .css({
                fontSize: '14px',
            })
            .attr({
                zIndex: 5,
                cursor: 'pointer',
            })
            .on('click', () => {
                chart.pointLabel?.destroy()
                chart.pointLabel = undefined
            })
            .add(groupLabel)

        chart.pointLabel = groupLabel
    }

    function createTooltipCluster(clusterData) {
        // console.log('clusteredData', clusterData)
        const arrLI = []
        const moreSites = []
        const arrCountries = []

        if (Array.isArray(clusterData) && clusterData.length > 0) {
            const count = clusterData.length
            const isHaveMore = count > 5

            clusterData.forEach((item, index) => {
                const { options: point } = item
                const { srvRiskScore, srvRisk, name, 'hc-key': hcKey } = point

                // if (isHaveMore) {
                createCountCountries(hcKey)
                // }

                if (index < 5) {
                    //Check risk color
                    const classBadge = `${srvRiskScore.toLowerCase()}-badge`
                    const liTmpl = `<li class="cluster-item">
                        ${name} <div class="risk-badge ${classBadge}">
                        ${srvRisk}</div></li>
                    `
                    //Append to list first 5 items
                    arrLI.push(liTmpl)
                }
            })
        }

        function createCountCountries(countryCode) {
            //---- Countires more...
            const { name } = getCountryFeature(countryCode).properties

            const currentCountry = arrCountries.find((item) => {
                if (item?.code === countryCode) return item
            })

            if (currentCountry) {
                currentCountry.count += 1
            } else {
                arrCountries.push({
                    name,
                    code: countryCode,
                    count: 1,
                })
            }
            //---- End Countries More

            return true
        }

        arrCountries.forEach((item) => {
            moreSites.push(`
            <span class="count-more"><b>${item.name}</b> (${item.count}); </span>
            `)
        })

        return `<ul class="ul-tooltip cluster">${arrLI.join('')}<hr />${moreSites.join('')}</ul>`
    }

    function createTooltipSingle(point) {
         //TODO Change srvLocation to the Country Name, City & Address
         //Check risk color
         const classBadge = `${point.srvRiskScore.toLowerCase()}-badge`
         return `
         <ul class="ul-tooltip">
             <li>
             ${point.name} <div class="risk-badge ${classBadge}">${point.srvRisk}</div>
             </li>
             <hr />
             <span class="count-more"><b>${point.srvLocation}</span>
         </ul>
         `
    }

    //---- Render Map by Risk
    async function renderByRiskSites(key = '') {
        currentMap = key === currentMap ? '' : key
        const sites = await mapPointsSliceByRisk(currentMap)
        return await render(sites)
    }

    //---- Slice Data by Risk Score
    function mapPointsSliceByRisk(risk = '') {
        if (!dataPointers) return

        if (!risk) return dataPointers

        return dataPointers.filter((srv) => {
            if (srv.srvRiskScore.toLowerCase() === risk.toLowerCase()) return srv
        })
    }

    //---- Search Site by Name (min 3 chars)
    function searchSites(str) {
        const re = new RegExp(`.?(${str}).?`, 'i')
        if (str.length === 0) {
            render(dataPointers)
            return
        }

        const searchResult = dataPointers.filter((srv) => {
            if (re.test(srv.name)) return srv
        })

        render(searchResult)
    }

    //---- Set visible Amount cluster
    function setVisibleClusterAmount() {
        if (isDebug) {
            console.log(`Method setVisibleClusterAmount()`)
        }
        const clusterLabelWrapper = document.querySelectorAll('.highcharts-series-2.highcharts-mappoint-series .highcharts-label[opacity="0"]')

        clusterLabelWrapper.forEach((element) => {
            element.setAttribute('opacity', 1)
        })
    }

    //---- Paint Cluster by Max Risk Status
    function paintCluster(chart) {
        const points = chart.series[2].points
        // console.log("POINTS", points)
        points.forEach((point) => {
            if (point.isCluster) {
                // debugger;
                const hState = getMaxStatus(point.clusteredData)
                const hColor = converter.siteRiskColor(hState)

                // point.dataLabel.element.setAttribute('opacity', 1)
                // // point.dataLabel.newOpacity = 1
                // // point.dataLabel.oldOpacity = 1
                // point.dataLabel.opacity = 1

                if (point.marker) {
                    point.marker.fillColor = hColor
                }

                if (point.graphic) {
                    point.graphic.fillColor = hColor
                    point.graphic.element.setAttribute('fill', hColor)
                    // console.log('POINT GRAPHIC', point, point.graphic.element)
                }
            }
        })
    }

    function buildSitePanel(data, type) {
        const panelInfo = document.querySelector(`#${mapId} .info__inner`)
        const panelBreadcrumbs = document.querySelector(`#${mapId} .site-breadcrumbs`)
        const panelContent = document.querySelector(`#${mapId} .panel__content`)
        const panelFooter = document.querySelector(`#${mapId} .panel__footer`)

        //Clear HTML
        panelBreadcrumbs.innerHTML = ""
        panelContent.innerHTML = ""
        panelFooter.innerHTML = ""

        switch (type) {
            case panelType.CLUSTER:
                panelBreadcrumbs.append(...generateHtml(getClusterHeaderHtml()))
                // panelBreadcrumbs.insertAdjacentHTML('beforeend', getClusterHeaderHtml())
                let tmpl = getClusterSitesHtml(data)
                panelContent.insertAdjacentHTML('beforeend', tmpl)
                break;
            case panelType.SITE:
                tmpl = JSON.stringify(data, null, 2)
                break;
        }




       panelInfo.classList.add("show")
    }

    //---- HELPER FUNCTIONS

    function getChart() {
        return chart
    }

    function debounce(cb, delay = 250) {
        let timeout

        return (...args) => {
          clearTimeout(timeout)
          timeout = setTimeout(() => {
            cb(...args)
          }, delay)
        }
    }

    //---- Animate Risk in DOM
    function animateRiskScore() {
        const elRiskH = document.querySelector(`#${mapId}-risk-h`)
        const elRiskM = document.querySelector(`#${mapId}-risk-m`)
        const elRiskL = document.querySelector(`#${mapId}-risk-l`)
        const elRiskN = document.querySelector(`#${mapId}-risk-n`)

        {
            let toH = 0
            let toM = 0
            let toL = 0
            let toN = 0

            if (hRisk > 0) {
                countsH = setInterval(() => {
                    elRiskH.innerHTML = ++toH
                    if (toH === hRisk) clearInterval(countsH)
                })
            }

            if (mRisk > 0) {
                countsM = setInterval(() => {
                    elRiskM.innerHTML = ++toM
                    if (toM === mRisk) clearInterval(countsM)
                })
            }

            if (lRisk > 0) {
                countsL = setInterval(() => {
                    elRiskL.innerHTML = ++toL
                    if (toL === lRisk) clearInterval(countsL)
                })
            }

            if (noRisk > 0) {
                countsN = setInterval(() => {
                    elRiskN.innerHTML = ++toN
                    if (toN === noRisk) clearInterval(countsN)
                })
            }
        }
    }

    //---- Close Info Panel on Zooming or click on another Point
    function closeInfoPanel() {
        const panelInfo = document.querySelector(`#${mapId} .info__inner`)
        if(panelInfo.classList.contains('show')){
            panelInfo.classList.remove('show')
        }
    }

    //---- Get Max Risk Status in the Cluster
    function getMaxStatus(items) {
        return items.reduce((acc, val) => {
            const valRisk = converter.probabilityRisk(val.options.srvRiskScore)
            const accRisk = converter.probabilityRisk(acc)
            // console.log(`${val.options.srvRiskScore} = ${valRisk} ?? ${acc} = ${accRisk}`)
            acc = acc === '' || valRisk > accRisk ? val.options.srvRiskScore : acc
            if (isDebug) {
                // console.log(`RETURN Max Status ${acc}`)
            }
            return acc
        }, '')
    }

    function clickOnPointHandler(point) {
        clearInterval(countTimer);
        return new Promise((resolve, reject) => {
            let count = 0;
            resolve(point.clusteredData);
            return
            countTimer = setInterval(() => {
                const isDestroyed = point?.destroyed;
                const isLastCluster = chart?.hoverPoint;
                count++;
                // console.log(`hoverPoint`, chart?.hoverPoint, chart)
                if (isNull(isLastCluster) && point.clusteredData) {
                    clearInterval(countTimer);
                    console.log(`This cluster is LAST attempt ${count}.`);

                    if(point.clusteredData) {
                        console.log(`This cluster not destroyed. Open Site Info`);
                        resolve(point.clusteredData);
                        return
                    }

                    resolve('drawn');
                    return;
                }
                else if (isDestroyed) {
                    clearInterval(countTimer);
                    console.log(`This cluster destroyed(${point?.destroyed} + attempt ${count}). Wait a new click on the single point or a new cluster`);
                    resolve('destroyed');
                    return;
                }

            }, 10)
        })

    }

    function isNull(value) {
        if (value === null){
            return true;
        }
    }

    function generateHtml(tmpl) {
        const docHTML = new DOMParser().parseFromString(tmpl, 'text/html')
        return docHTML.body.children;
    }

    const getRootHtml = () => `
        <div class="map-header" id=${headerId}>
            <div class="jq-wgt-title">SITES MAP</div>
            <div><input type="text" id="${mapId}-search-input" class="search-input" /></div>
        </div>
        <div class="map-container" id=${mapId}>
            <div class="map__inner"></div>
            <div class="info__inner">
                <div class="panel__header">
                    <div class="site-breadcrumbs"></div>
                    <div class="btn-close"></div>
                </div>
                <div class="panel__content"></div>
                <div class="panel__footer"></div>

            </div>
        </div>
        <div class="map-footer" id=${footerId}>
            <div class="btn-wrapper">
                <button id="${mapId}-zoomIn">+</button>
                <button id="${mapId}-zoomOut">-</button>
                <button id="${mapId}-zoomReset">Reset</button>
            </div>
            <div class="risk-wrapper">
                Risk Score:
                <div class="risk-wrapper-item"><a href="#" onclick="map.renderMap('h')"><div class="risk-sq h-badge"></div>High <span class="risk-score-number" id="${mapId}-risk-h"></span></a></div>
                <div class="risk-wrapper-item"><a href="#" onclick="map.renderMap('m')"><div class="risk-sq m-badge"></div>Medium <span class="risk-score-number" id="${mapId}-risk-m"></span></a></div>
                <div class="risk-wrapper-item"><a href="#" onclick="map.renderMap('l')"><div class="risk-sq l-badge"></div>Low <span class="risk-score-number" id="${mapId}-risk-l"></span></a></div>
                <div class="risk-wrapper-item"><a href="#" onclick="map.renderMap('n')"><div class="risk-sq n-badge"></div>No Score <span class="risk-score-number" id="${mapId}-risk-n"></span></a></div>
            </div>
        </div>
    `

    const getClusterHeaderHtml = () => `
        <h3>Site Cluster</h3>
        <h5>Select site to view more details</h5>
    `

    const getClusterSitesHtml = (data) => {

        const arrTmpl = []
        const tmpl = (point) => {
            const item = point.options
            const cssClassBadge = `${item.srvRiskScore.toLowerCase()}-badge`
            return `
            <div class='info-flex-row'>
                <div class='site-name'>
                    ${item.name}
                    <div class="info-point-status">Up (12 Days)</div>
                </div>
                <div>
                    <div class='risk-badge ${cssClassBadge}'>${item.srvRisk}</div>
                </div>
                <div>
                    <div class='get-info-arrow'></div>
                </div>
            </div>
            `
        }

        if (Array.isArray(data)) {
            data.forEach((item) => {
                 arrTmpl.push(tmpl(item))
            })
        }

        return arrTmpl.join('')

    }

    let observer;

    const createMutationObserver = () => {

        // instance
        observer = observer ?? new MutationObserver(function(mutations) {
            console.log(`mutations =`, mutations); // MutationRecord
            mutations.forEach(function(mutation) {
                // console.log("mutation =", mutation);
                if (config.characterData && mutation.type === "characterData") {
                    // target & object === typeof(mutation.target)
                    // console.log("A child node has been added OR removed.", mutation.target, typeof(mutation.target));
                    // console.log("[...mutation.addedNodes].length", [...mutation.addedNodes].length);
                    // console.log("[...mutation.removedNodes].length", [...mutation.removedNodes].length);
                    // if (mutation.target && [...mutation.addedNodes].length) {
                    //     // [...mutation.addedNodes].length
                    //     console.log(`A child node ${mutation.target} has been added!`, mutation.target);
                    // }
                    // if (mutation.target && [...mutation.removedNodes].length) {
                    //     // [...mutation.removedNodes].length
                    //     console.log(`A child node ${mutation.target} has been removed!`, mutation.target);
                    // }
                }

                if (config.childList && mutation.type === "childList") {
                    if (mutation.target && [...mutation.addedNodes].length) {
                        console.log(`A child node ${mutation.target} has been added!`, mutation.target);
                    }
                    if (mutation.target && [...mutation.removedNodes].length) {
                        console.log(`A child node ${mutation.target} has been removed!`, mutation.target);
                    }
                    // do somwthings
                    let list_values = [];
                    list_values = [].slice.call(list.children).map(function(node) {
                        return node.innerHTML;
                    }).filter(function(str) {
                        if (str === "<br>") {
                            return false;
                        } else {
                            return true;
                        }
                    });
                    console.log(list_values);
                }

                if (config.attributes && mutation.type === "attributes") {
                    console.log("mutation =", mutation);
                    console.log(`The \`${mutation.attributeName}\` attribute was modified.`);
                    // console.log("list style =", list.style);
                    let {
                        width,
                        height,
                    } = list.style;
                    let style = {
                        width,
                        height
                    };
                    console.log("style =\n", JSON.stringify(style, null, 4));
                }
            });
        });

        return observer
    }

    //TODO Change
    function prepareData(data) {
        const _data = data.map((item) => {
            const srvRiskScore = getRandomArrItem()
            let srvRisk = generateRiskRandom()
            let _lat = item.srv_latitude
            let _lon = item.srv_longitude
            let _srvId = item.srv_id

            const isSameCoordinates = checkSameCoordinate(data, _srvId, _lat, item.srv_longitude)

            if (isSameCoordinates) {
                _lat = `${_lat.slice(0, -1)}${generateRiskRandom(2)}`
                _lon = `${_lon.slice(0, -1)}${generateRiskRandom(2)}`
            }

            switch (srvRiskScore) {
                case 'H':
                    hRisk++
                    break
                case 'M':
                    mRisk++
                    break
                case 'L':
                    lRisk++
                    break
                default:
                    noRisk++
                    srvRisk = 0
                    break
            }

            return {
                lat: Number(_lat), //new field
                lon: Number(_lon), //new field
                country: item.srv_country.toLowerCase(), //new field
                name: item.srv_name,
                marker: converter.pointMarker(srvRiskScore),
                srvId: item.srv_id,
                srvLocation: item.srv_location,
                srvFirstName: item.srv_contact_first_name,
                srvLastName: item.srv_contact_last_name,
                srvCompany: item.srv_contact_company,
                srvEmail: item.srv_contact_email,
                srvPhone: item.srv_contact_phone,
                srvRiskScore,
                srvRisk,
                srvStatus: 'up',
            }
        })

        return _data
    }

    Init()


    return {
        mapId,
        chart: getChart,
        renderMap: renderByRiskSites,
        searchSites,
        setVisibleClusterAmount
    }
}

function generateRiskRandom(maxLimit = 100) {
    const rand = Math.random() * maxLimit // say 99.81321410836433
    return Math.floor(rand) // 99
}

function getRandomArrItem(arr = arrRisk) {
    // get random index value
    const randomIndex = Math.floor(Math.random() * arr.length)

    // get random item
    const item = arr[randomIndex]

    return item
}

function RiskParamsConverter() {
    return {
        siteRiskColor(data) {
            const Colors = {
                H: '#D60B13',
                M: '#FFC527',
                L: '#279D2B',
                D: '#B0B0B0',
            }
            return Colors[data] ? Colors[data] : ''
        },
        probabilityRisk(data) {
            const Risk = {
                H: 4,
                M: 3,
                L: 2,
                D: 1,
            }
            return Risk[data] ? Risk[data] : ''
        },
        pointMarker(srvRiskScore) {
            switch (srvRiskScore) {
                case 'H':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-red.png)',
                    }
                case 'M':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-yellow.png)',
                    }
                case 'L':
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-green.png)',
                    }
                default:
                    return {
                        width: 35,
                        height: 35,
                        symbol: 'url(/assets/map/images/pin-gray.png)',
                    }
            }
        },
        riskSeverity(sev) {
            const riskSeverity = {
                L: 'Low',
                M: 'Medium',
                H: 'High',
            }
            return riskSeverity[sev] ? riskSeverity[sev] : ''
        },
    }
}

const converter = RiskParamsConverter()
