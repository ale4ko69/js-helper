
export const customEvents = {
    closeBox: 'closeBox',
    selectedOption: 'selectedOption'
}

export const createCustomEvent = (eventName, payload = {}) => {
    return new CustomEvent(eventName, { detail: payload });
}

